"""Dataset-preparation tests on fake folders that mimic the documented CASIA v2 / DEFACTO / NIST naming schemes."""
import cv2
import numpy as np
import pandas as pd

from resforge.data.metadata import check_files, load_metadata
from resforge.data.prepare import prepare_casia2, prepare_defacto12k, prepare_nist16


def _img(path, arr):
    path.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(path), arr)


def _noise(seed, size=96):
    return np.random.default_rng(seed).integers(0, 255, (size, size, 3), dtype=np.uint8)


def test_prepare_casia2_subtraction_and_provided(tmp_path):
    raw, out = tmp_path / "CASIA2", tmp_path / "proc"
    au = _noise(0)
    _img(raw / "Au" / "Au_ani_00018.jpg", au)
    _img(raw / "Au" / "Au_pla_00001.jpg", _noise(1))
    tp = au.copy(); tp[20:50, 30:70] = 255 - tp[20:50, 30:70]
    _img(raw / "Tp" / "Tp_D_CND_M_N_ani00018_sec00096_00138.png", tp)                 # matched, aligned
    _img(raw / "Tp" / "Tp_S_NNN_S_N_pla00001_pla00001_00002.png", cv2.resize(_noise(1), (80, 80)))  # size mismatch -> no mask
    _img(raw / "Tp" / "Tp_D_CRN_M_N_art00067_nat00059_11805.png", _noise(5))          # no authentic parent
    df = prepare_casia2(raw, out, mask_source="subtraction", mask_size=64)
    assert len(df) == 5 and (df.label == 0).sum() == 2
    ok = df[df.image_path.str.contains("ani00018_sec00096")].iloc[0]
    assert ok.mask_path and ok.group == "ani00018"
    assert df[df.label == 0].set_index("group").index.isin(["ani00018", "pla00001"]).all()
    m = cv2.imread(str(out / ok.mask_path), 0)
    assert m.shape == (64, 64) and 0.05 < (m > 0).mean() < 0.5
    assert (df.has_mask.sum() if "has_mask" in df else (df.mask_path != "").sum()) == 1
    meta = load_metadata(out / "casia2_metadata.csv"); check_files(meta, out)

    gt = tmp_path / "gt"
    mk = np.zeros((96, 96), np.uint8); mk[20:50, 30:70] = 255
    _img(gt / "Tp_D_CND_M_N_ani00018_sec00096_00138_gt.png", mk)
    df2 = prepare_casia2(raw, out, mask_source="provided", gt_dir=gt, mask_size=64, out_csv=out / "casia_provided.csv")
    assert (df2.mask_path != "").sum() == 1


def test_prepare_defacto12k(tmp_path):
    root, coco, out = tmp_path / "defacto", tmp_path / "coco", tmp_path / "proc"
    for i, kind in enumerate(["splicing", "copymove", "inpainting"] * 4):
        cid = 1000 + i
        _img(coco / "train2014" / f"COCO_train2014_{cid:012d}.jpg", _noise(i))
        stem = f"{cid:012d}_{kind}"
        _img(root / kind / f"{kind}_1_img" / "img" / f"{stem}.jpg", _noise(i + 50))
        mk = np.zeros((96, 96), np.uint8); mk[10:40, 10:40] = 255
        _img(root / kind / f"{kind}_1_annotations" / "probe_mask" / f"{stem}.png", mk)
    df = prepare_defacto12k(root, coco, out, n_tampered=9, mask_size=64, seed=0)
    assert (df.label == 1).sum() == 9 and (df.label == 0).sum() == 9
    assert df.groupby("group").label.nunique().eq(2).all()  # every parent has its authentic + tampered image
    check_files(load_metadata(out / "defacto12k_metadata.csv"), out)


def test_prepare_nist16_dirs_and_inverted_masks(tmp_path):
    t, m, a, out = tmp_path / "probe", tmp_path / "mask", tmp_path / "base", tmp_path / "proc"
    for i in range(3):
        _img(t / f"p{i}.jpg", _noise(i)); _img(a / f"b{i}.jpg", _noise(i + 9))
        mk = np.full((96, 96), 255, np.uint8); mk[10:30, 10:30] = 0       # NIST-style: manipulated = black
        _img(m / f"p{i}_mask.png", mk)
    pd.DataFrame({"probe": [f"p{i}.jpg" for i in range(3)], "base": [f"b{i}.jpg" for i in range(3)]}).to_csv(tmp_path / "pairs.csv", index=False)
    df = prepare_nist16(out, tampered_dir=t, mask_dir=m, authentic_dir=a, pairs_csv=tmp_path / "pairs.csv", mask_size=64)
    assert len(df) == 6 and (df.mask_path != "").sum() == 3
    assert set(df[df.label == 1].group) == set(df[df.label == 0].group) == {"b0", "b1", "b2"}
    mask = cv2.imread(str(out / df[df.label == 1].mask_path.iloc[0]), 0)
    assert (mask > 0).mean() < 0.5  # auto-inverted: forged region is the minority class
