"""CPU smoke tests on tiny synthetic data - they check the code runs end to end, not that it reproduces the paper."""
import json
from pathlib import Path

import numpy as np
import pytest
import torch

from resforge import load_config
from resforge.data.metadata import load_metadata
from resforge.data.splits import group_split
from resforge.data.synthetic import make_synthetic_dataset
from resforge.eval.metrics import evaluate_heatmaps, pixel_scores, select_threshold
from resforge.eval.robustness import gaussian_blur, gaussian_noise, jpeg_compress
from resforge.eval.stats import compare_to_proposed, holm_bonferroni
from resforge.models.backbone import ResNetFPNBackbone
from resforge.models.baselines import build_classifier, build_segmenter
from resforge.models.coordatt import CoordAtt
from resforge.models.detector import ResForgeDetector
from resforge.models.localizer import build_maskrcnn


@pytest.fixture(scope="module")
def cfg():
    return load_config("configs/demo.yaml")


@pytest.fixture(scope="module")
def synth(tmp_path_factory):
    root = tmp_path_factory.mktemp("synth")
    make_synthetic_dataset(root, "synthetic", n_parents=40, size=128)
    return root, load_metadata(root / "synthetic_metadata.csv")


def test_coordatt_shape():
    x = torch.randn(2, 64, 20, 12)
    assert CoordAtt(64)(x).shape == x.shape


def test_detector_freezing():
    m = ResForgeDetector(pretrained=False)
    assert not any(p.requires_grad for n in ("conv1", "bn1", "layer1", "layer2") for p in getattr(m, n).parameters())
    assert all(p.requires_grad for p in m.layer3.parameters()) and all(p.requires_grad for p in m.head.parameters())
    assert m(torch.randn(3, 3, 128, 128)).shape == (3,)


def test_res2net_ca_inserted_before_conv3(cfg):
    b = ResNetFPNBackbone("res2net50_26w_4s", coordinate_attention=True, pretrained=False)
    assert b.num_ca_blocks == 4 + 6 + 3  # Res2Net-50 stages [3,4,6,3]; CA in layer2..layer4 only
    blk = b.layer2[0]
    assert isinstance(blk.conv3[0], CoordAtt)
    out = b(torch.randn(1, 3, 128, 128))
    assert list(out) == ["0", "1", "2"] and out["0"].shape[-1] == 16


def test_maskrcnn_train_and_eval(cfg):
    m = build_maskrcnn(cfg.stage2)
    img = [torch.rand(3, 128, 128)]
    mask = torch.zeros(1, 128, 128, dtype=torch.uint8)
    mask[0, 30:70, 30:70] = 1
    tgt = [{"boxes": torch.tensor([[30.0, 30, 70, 70]]), "labels": torch.ones(1, dtype=torch.int64), "masks": mask}]
    m.train()
    losses = m(img, tgt)
    assert {"loss_classifier", "loss_box_reg", "loss_mask", "loss_objectness", "loss_rpn_box_reg"} <= set(losses)
    m.eval()
    assert isinstance(m(img), list)


@pytest.mark.parametrize("name", ["vgg16", "densenet121", "vit_b32"])
def test_classifier_baselines(name):
    assert build_classifier(name, 128, pretrained=False)(torch.randn(2, 3, 128, 128)).shape == (2,)


@pytest.mark.parametrize("name", ["unet", "fcn", "segnet"])
def test_segmentation_baselines(name):
    assert build_segmenter(name, pretrained=False)(torch.rand(2, 3, 128, 128)).shape == (2, 1, 128, 128)


def test_group_split_no_leakage(synth):
    _, df = synth
    tr, va, te = group_split(df, seed=1)
    assert set(tr.group).isdisjoint(va.group) and set(tr.group).isdisjoint(te.group) and set(va.group).isdisjoint(te.group)
    assert len(tr) + len(va) + len(te) == len(df)


def test_metrics_and_stats():
    gt = np.zeros((8, 8), np.uint8); gt[2:6, 2:6] = 1
    s = pixel_scores(gt, gt)
    assert s["iou"] == 1.0 and s["f1"] == 1.0
    assert pixel_scores(np.zeros_like(gt), gt)["iou"] == 0.0
    res = evaluate_heatmaps([(gt.astype(np.float32), gt)], thresholds=[0.5])
    assert res[0.5]["iou"] == 100.0
    assert select_threshold(np.array([0, 0, 1, 1]), np.array([0.1, 0.2, 0.8, 0.9]), [0.3, 0.5, 0.7]) in (0.3, 0.5, 0.7)
    adj, thr, sig = holm_bonferroni([0.001, 0.04, 0.03, 0.2])
    assert np.allclose(adj, [0.004, 0.09, 0.09, 0.2])                      # step-down, monotone
    assert np.allclose(thr, [0.0125, 0.025, 0.05 / 3, 0.05])               # alpha / (m - k + 1) by rank
    assert list(sig) == [True, False, False, False]
    rng = np.random.default_rng(0)
    base = rng.normal(90, 1, 20)
    tbl = compare_to_proposed({"ResForge": base + 2, "A": base, "B": base - 1})
    assert tbl.significant.all() and (tbl.dz > 1).all()


def test_perturbations():
    img = np.random.default_rng(0).integers(0, 255, (64, 64, 3), dtype=np.uint8)
    for f in (gaussian_blur(3), gaussian_noise(0.01), jpeg_compress(50)):
        out = f(img)
        assert out.shape == img.shape and out.dtype == np.uint8
    assert np.array_equal(gaussian_noise(0.01)(img), gaussian_noise(0.01)(img))  # deterministic


@pytest.mark.slow
def test_end_to_end_one_seed(cfg, synth, tmp_path):
    from resforge.experiment import run_experiment
    root, df = synth
    agg = run_experiment("synthetic", df, root, cfg, seeds=[0], out_dir=tmp_path, num_workers=0, verbose=False)
    assert (tmp_path / "seed0" / "metrics.json").exists() and (tmp_path / "seed0" / "stage2_maskrcnn.pt").exists()
    m = json.load(open(tmp_path / "seed0" / "metrics.json"))
    assert {"detection", "localization_standalone", "localization_full_pipeline", "authentic_false_alarms"} <= set(m)
    assert not agg.empty


@pytest.mark.slow
def test_end_to_end_with_baselines(cfg, synth, tmp_path):
    from resforge import load_config
    from resforge.experiment import run_experiment, runs_table
    c = load_config("configs/demo.yaml", {"stage1": {"epochs": 1}, "stage2": {"epochs": 1}, "baselines": {
        "classification": ["densenet121"], "localization": ["unet"], "epochs": 1, "img_size": 128, "batch_size": 8}})
    root, df = synth
    agg = run_experiment("synthetic_bl", df, root, c, seeds=[0, 1], out_dir=tmp_path, run_baselines=True, num_workers=0, verbose=False)
    assert {"densenet121", "unet", "ResForge"} <= set(agg.model.str.replace(r" \(.*\)", "", regex=True))
    f1 = runs_table(tmp_path).query("task == 'detection' and metric == 'f1'").pivot(index="seed", columns="model", values="value")
    from resforge.eval.stats import compare_to_proposed
    assert len(compare_to_proposed({m: f1[m].values for m in f1})) == 1
