"""Small shared helpers: seeding, device, early stopping, parameter counting."""
from __future__ import annotations

import copy
import json
import os
import random
from pathlib import Path
from typing import Any, Optional

import numpy as np
import torch
import torch.nn as nn


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)


def get_device(prefer: str = "auto") -> torch.device:
    if prefer != "auto":
        return torch.device(prefer)
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def count_params(model: nn.Module, trainable_only: bool = False) -> int:
    return sum(p.numel() for p in model.parameters() if (p.requires_grad or not trainable_only))


class EarlyStopping:
    """Tracks the best monitored value, keeps a copy of the best weights, signals when to stop."""

    def __init__(self, patience: int, mode: str = "min"):
        assert mode in ("min", "max")
        self.patience, self.mode = patience, mode
        self.best: Optional[float] = None
        self.best_state: Optional[dict] = None
        self.best_epoch = -1
        self.bad = 0

    def step(self, value: float, model: nn.Module, epoch: int) -> bool:
        """Returns True when training should stop."""
        better = self.best is None or (value < self.best if self.mode == "min" else value > self.best)
        if better:
            self.best, self.best_epoch, self.bad = value, epoch, 0
            self.best_state = copy.deepcopy({k: v.detach().cpu() for k, v in model.state_dict().items()})
        else:
            self.bad += 1
        return self.bad >= self.patience

    def restore(self, model: nn.Module) -> None:
        if self.best_state is not None:
            model.load_state_dict(self.best_state)


def save_json(obj: Any, path: str | Path) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)

    def default(o):
        if isinstance(o, (np.floating, np.integer)):
            return o.item()
        if isinstance(o, np.ndarray):
            return o.tolist()
        raise TypeError(type(o))

    with open(path, "w") as f:
        json.dump(obj, f, indent=2, default=default)


def grid(spec) -> np.ndarray:
    """[start, stop, step] (inclusive) -> numpy grid."""
    start, stop, step = spec
    return np.round(np.arange(start, stop + step / 2, step), 6)
