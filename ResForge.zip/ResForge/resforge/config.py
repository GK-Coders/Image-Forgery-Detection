"""YAML configuration loading with deep-merge overrides and attribute access."""
from __future__ import annotations

import copy
from pathlib import Path
from typing import Any, Dict, Optional

import yaml

REPO_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG = REPO_ROOT / "configs" / "default.yaml"


class Cfg(dict):
    """dict with attribute access (cfg.stage1.lr)."""

    def __getattr__(self, k: str) -> Any:
        try:
            return self[k]
        except KeyError as e:  # pragma: no cover
            raise AttributeError(k) from e

    def __setattr__(self, k: str, v: Any) -> None:
        self[k] = v

    def to_dict(self) -> Dict[str, Any]:
        return {k: (v.to_dict() if isinstance(v, Cfg) else v) for k, v in self.items()}


def _wrap(d: Dict[str, Any]) -> Cfg:
    return Cfg({k: _wrap(v) if isinstance(v, dict) else v for k, v in d.items()})


def _merge(base: Dict[str, Any], over: Dict[str, Any]) -> Dict[str, Any]:
    out = copy.deepcopy(base)
    for k, v in over.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


def load_config(*overlays: Optional[str | Path | Dict[str, Any]]) -> Cfg:
    """Load ``configs/default.yaml`` and deep-merge any overlay YAML paths / dicts on top.

    Example: ``load_config("configs/demo.yaml", {"stage1": {"epochs": 2}})``
    """
    with open(DEFAULT_CONFIG) as f:
        cfg = yaml.safe_load(f)
    for o in overlays:
        if o is None:
            continue
        if isinstance(o, (str, Path)):
            p = Path(o)
            if not p.is_absolute() and not p.exists():
                p = REPO_ROOT / p
            with open(p) as f:
                o = yaml.safe_load(f) or {}
        cfg = _merge(cfg, o)
    return _wrap(cfg)
