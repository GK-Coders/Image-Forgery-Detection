"""Parameter count, inference latency and peak GPU memory (paper Sec. 4.8, Table 8).

Protocol: batch size 1, FP32, ``torch.cuda.synchronize()`` around every timed call, ``warmup_iters`` warm-up runs then the mean
of ``timed_iters`` runs. Stage 1 and Stage 2 are profiled sequentially; ResForge latency = Stage 1 + Stage 2 (a forged image
traverses both stages). Peak memory is only available on CUDA devices.
"""
from __future__ import annotations

import time
from typing import Callable, Dict, Optional

import torch
import torch.nn as nn

from ..utils import count_params


def _sync(device):
    if device.type == "cuda":
        torch.cuda.synchronize()


@torch.no_grad()
def profile_callable(fn: Callable[[], object], device, warmup: int, iters: int) -> Dict[str, Optional[float]]:
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats()
    for _ in range(warmup):
        fn()
    _sync(device)
    t0 = time.perf_counter()
    for _ in range(iters):
        fn()
        _sync(device)
    lat = (time.perf_counter() - t0) / max(iters, 1)
    mem = torch.cuda.max_memory_allocated() / 1024 ** 3 if device.type == "cuda" else None
    return {"latency_s": lat, "peak_gpu_gb": mem}


def profile_resforge(det: nn.Module, loc: nn.Module, cfg, device) -> Dict[str, Dict[str, Optional[float]]]:
    p = cfg.profiling
    det.eval().to(device)
    loc.eval().to(device)
    x1 = torch.rand(p.batch_size, 3, cfg.stage1.img_size, cfg.stage1.img_size, device=device)
    x2 = [torch.rand(3, p.img_size, p.img_size, device=device) for _ in range(p.batch_size)]
    s1 = profile_callable(lambda: det(x1), device, p.warmup_iters, p.timed_iters)
    s2 = profile_callable(lambda: loc(x2), device, p.warmup_iters, p.timed_iters)
    return {
        "stage1": {"params_M": count_params(det) / 1e6, **s1},
        "stage2": {"params_M": count_params(loc) / 1e6, **s2},
        "resforge_total": {
            "params_M": (count_params(det) + count_params(loc)) / 1e6,
            "latency_s": s1["latency_s"] + s2["latency_s"],
            "peak_gpu_gb": max(s1["peak_gpu_gb"] or 0, s2["peak_gpu_gb"] or 0) or None,
        },
    }
