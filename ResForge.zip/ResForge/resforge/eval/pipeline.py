"""End-to-end two-stage evaluation (paper Sec. 3, intro).

Stage 2 is reported twice, exactly as the paper describes:
  * standalone  - Stage 2 run on every forged test image (Stage 1 bypassed, ground-truth forged);
  * full pipeline - an image Stage 1 calls 'authentic' gets an empty mask (cascade error), so Stage-1 misses count as IoU = 0.
In addition the localiser is run on authentic test images that Stage 1 wrongly flags, to quantify false localisations.
"""
from __future__ import annotations

from typing import Callable, Dict, Optional

import numpy as np
import pandas as pd

from ..train.classifier import predict_probs
from ..train.localizer import iter_heatmaps_maskrcnn
from .metrics import detection_metrics, pixel_auc, pixel_scores


def evaluate_pipeline(det_model, loc_model, te_df: pd.DataFrame, root, cfg, thr_cls: float, thr_loc: float, device,
                      num_workers: int = 0, perturb: Optional[Callable] = None) -> Dict[str, Dict[str, float]]:
    s1, s2 = cfg.stage1, cfg.stage2
    te_df = te_df.reset_index(drop=True)
    probs = predict_probs(det_model, te_df, root, s1.img_size, s1.batch_size, device, num_workers, perturb, s1.amp)
    det = detection_metrics(te_df.label.values, probs, thr_cls)

    pos = np.flatnonzero(te_df.has_mask.values)
    forged = te_df.iloc[pos].reset_index(drop=True)
    accepted = probs[pos] >= thr_cls
    alone, full, aucs = [], [], []
    it = iter_heatmaps_maskrcnn(loc_model, forged, root, s2.img_size, device, batch_size=min(s2.micro_batch_size, 8),
                                perturb=perturb, heatmap_mode=s2.heatmap_mode, num_workers=num_workers)
    for i, (heat, gt) in enumerate(it):
        s = pixel_scores(heat >= thr_loc, gt)
        alone.append(s)
        full.append(s if accepted[i] else pixel_scores(np.zeros_like(gt), gt))
        aucs.append(pixel_auc(heat, gt))

    def mean(rows):
        return {k: 100 * float(np.mean([r[k] for r in rows])) for k in ("precision", "recall", "f1", "iou")} if rows else {}

    standalone = mean(alone)
    standalone["auc"] = 100 * float(np.nanmean(aucs)) if aucs else float("nan")
    standalone["n"] = len(alone)
    pipeline = mean(full)
    pipeline["n"] = len(full)
    pipeline["stage1_recall_on_forged"] = 100 * float(accepted.mean()) if len(accepted) else float("nan")

    # authentic images wrongly passed to Stage 2
    neg = np.flatnonzero((te_df.label.values == 0) & (probs >= thr_cls))
    auth = {"n_authentic": int((te_df.label == 0).sum()), "n_flagged_by_stage1": int(len(neg)), "localised_fp_rate": 0.0, "mean_pred_area_pct": 0.0}
    if len(neg):
        aut = te_df.iloc[neg].reset_index(drop=True)
        areas = [float((h >= thr_loc).mean()) for h, _ in iter_heatmaps_maskrcnn(
            loc_model, aut, root, s2.img_size, device, batch_size=min(s2.micro_batch_size, 8), perturb=perturb,
            heatmap_mode=s2.heatmap_mode, num_workers=num_workers, allow_no_mask=True)]
        auth["localised_fp_rate"] = 100 * float(np.mean([a > 0 for a in areas]))
        auth["mean_pred_area_pct"] = 100 * float(np.mean(areas))
    return {"detection": det, "localization_standalone": standalone, "localization_full_pipeline": pipeline, "authentic_false_alarms": auth}
