"""Post-processing robustness study (paper Sec. 4.5, Figs. 7-9).

Perturbations are applied to the (already resized) uint8 RGB test image:
  Gaussian blur, kernel k in {3, 15};  additive Gaussian noise on [0,1] images with variance in {0.002, 0.01};
  JPEG re-compression with quality in {50, 90}.
Pixel-level localisation F1 is reported on the clean data and the six corrupted conditions.
"""
from __future__ import annotations

import zlib
from collections import OrderedDict
from typing import Callable, Dict, Iterator, Optional, Tuple

import cv2
import numpy as np
import pandas as pd

from .metrics import evaluate_heatmaps

Perturb = Callable[[np.ndarray], np.ndarray]


def gaussian_blur(k: int) -> Perturb:
    return lambda img: cv2.GaussianBlur(img, (k, k), 0)


def gaussian_noise(var: float, seed: int = 0) -> Perturb:
    std = float(np.sqrt(var))

    def f(img: np.ndarray) -> np.ndarray:
        rng = np.random.default_rng((zlib.crc32(np.ascontiguousarray(img[::8, ::8]).tobytes()) ^ seed) & 0xFFFFFFFF)  # deterministic per image
        x = img.astype(np.float32) / 255.0 + rng.normal(0.0, std, img.shape).astype(np.float32)
        return (np.clip(x, 0, 1) * 255 + 0.5).astype(np.uint8)

    return f


def jpeg_compress(q: int) -> Perturb:
    def f(img: np.ndarray) -> np.ndarray:
        ok, buf = cv2.imencode(".jpg", cv2.cvtColor(img, cv2.COLOR_RGB2BGR), [cv2.IMWRITE_JPEG_QUALITY, int(q)])
        assert ok
        return cv2.cvtColor(cv2.imdecode(buf, cv2.IMREAD_COLOR), cv2.COLOR_BGR2RGB)

    return f


def robustness_conditions(cfg_rob) -> "OrderedDict[str, Optional[Perturb]]":
    c: "OrderedDict[str, Optional[Perturb]]" = OrderedDict([("clean", None)])
    for k in cfg_rob.blur_kernels:
        c[f"GSBlur k={k}"] = gaussian_blur(int(k))
    for v in cfg_rob.noise_variances:
        c[f"GSNoise var={v}"] = gaussian_noise(float(v))
    for q in cfg_rob.jpeg_qualities:
        c[f"JPEGComp q={q}"] = jpeg_compress(int(q))
    return c


def evaluate_robustness(
    models: Dict[str, Callable[[Optional[Perturb]], Iterator[Tuple[np.ndarray, np.ndarray]]]],
    conditions: Dict[str, Optional[Perturb]],
    thresholds: Dict[str, float],
) -> pd.DataFrame:
    """``models[name](perturb)`` must return an iterator of (heat, gt); ``thresholds[name]`` is its binarisation threshold."""
    rows = []
    for name, fn in models.items():
        for cname, pert in conditions.items():
            r = evaluate_heatmaps(fn(pert), thresholds=[thresholds[name]], compute_auc=False)[float(thresholds[name])]
            rows.append(dict(model=name, condition=cname, pixel_f1=r["f1"], iou=r["iou"]))
    return pd.DataFrame(rows)
