"""Metrics (paper Sec. 4.3, Eqs. 7-15).

Detection: forged = positive class; precision / recall / F1 / ROC-AUC at a validation-selected threshold.
Localisation: computed per image and macro-averaged over test images; pixel AUC uses the continuous heat-map.
"""
from __future__ import annotations

from typing import Dict, Iterable, Iterator, Sequence, Tuple

import numpy as np
from sklearn.metrics import precision_recall_fscore_support, roc_auc_score, roc_curve


# ----------------------------------------------------------------------------- image level
def select_threshold(y: np.ndarray, p: np.ndarray, grid: Sequence[float]) -> float:
    """Threshold maximising the F1 of the forged class on the validation set (ties -> closest to 0.5)."""
    best, best_t = -1.0, 0.5
    for t in grid:
        _, _, f1, _ = precision_recall_fscore_support(y, (p >= t).astype(int), average="binary", zero_division=0)
        if f1 > best + 1e-12 or (abs(f1 - best) <= 1e-12 and abs(t - 0.5) < abs(best_t - 0.5)):
            best, best_t = f1, float(t)
    return best_t


def detection_metrics(y: np.ndarray, p: np.ndarray, thr: float) -> Dict[str, float]:
    pred = (p >= thr).astype(int)
    pr, rc, f1, _ = precision_recall_fscore_support(y, pred, average="binary", zero_division=0)
    auc = float(roc_auc_score(y, p)) if len(np.unique(y)) == 2 else float("nan")
    return {"precision": 100 * pr, "recall": 100 * rc, "f1": 100 * f1, "auc": 100 * auc, "accuracy": 100 * float((pred == y).mean()), "threshold": float(thr)}


def roc_points(y: np.ndarray, p: np.ndarray):
    fpr, tpr, _ = roc_curve(y, p)
    return fpr, tpr


# ----------------------------------------------------------------------------- pixel level
def pixel_scores(pred: np.ndarray, gt: np.ndarray) -> Dict[str, float]:
    """Per-image pixel precision / recall / F1 / IoU for binary masks (Eqs. 11-13, 15). Zero-division -> 0."""
    pred, gt = pred.astype(bool), gt.astype(bool)
    tp = float(np.logical_and(pred, gt).sum())
    fp = float(np.logical_and(pred, ~gt).sum())
    fn = float(np.logical_and(~pred, gt).sum())
    prec = tp / (tp + fp) if tp + fp > 0 else 0.0
    rec = tp / (tp + fn) if tp + fn > 0 else 0.0
    f1 = 2 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn > 0 else 0.0
    iou = tp / (tp + fp + fn) if tp + fp + fn > 0 else 0.0
    return {"precision": prec, "recall": rec, "f1": f1, "iou": iou}


def pixel_auc(heat: np.ndarray, gt: np.ndarray) -> float:
    g = gt.reshape(-1).astype(bool)
    if g.all() or not g.any():
        return float("nan")
    return float(roc_auc_score(g, heat.reshape(-1)))


def evaluate_heatmaps(
    it: Iterable[Tuple[np.ndarray, np.ndarray]],
    thresholds: Sequence[float] = (0.5,),
    compute_auc: bool = True,
    reject: Sequence[bool] | None = None,
) -> Dict[float, Dict[str, float]] | Dict:
    """Consume (heat, gt) pairs; return macro-averaged metrics (in %) for every threshold, plus ``auc`` (key 'auc').

    ``reject[i] = True`` replaces image i's heat-map by an empty (all-zero) mask, i.e. a Stage-1 miss in the full pipeline.
    """
    per = {float(t): {k: [] for k in ("precision", "recall", "f1", "iou")} for t in thresholds}
    aucs = []
    n = 0
    for i, (heat, gt) in enumerate(it):
        if reject is not None and reject[i]:
            heat = np.zeros_like(heat)
        for t in thresholds:
            s = pixel_scores(heat >= t, gt)
            for k, v in s.items():
                per[float(t)][k].append(v)
        if compute_auc:
            aucs.append(pixel_auc(heat, gt))
        n += 1
    out = {t: {k: 100 * float(np.mean(v)) if v else float("nan") for k, v in d.items()} for t, d in per.items()}
    out = {t: {**d, "n": n} for t, d in out.items()}
    if compute_auc:
        a = [x for x in aucs if not np.isnan(x)]
        out["auc"] = 100 * float(np.mean(a)) if a else float("nan")
    return out


def best_threshold_by_f1(res: Dict) -> float:
    ts = [t for t in res if isinstance(t, float)]
    return max(ts, key=lambda t: (res[t]["f1"], -abs(t - 0.5)))
