"""Statistical analysis (paper Sec. 4.6, Tables 5-6): paired t-tests across matched runs with Holm-Bonferroni correction.

``scores[method]`` is an array of one score per run (same seeds / partitions for every method), e.g. the detection F1 over
the 20 repeated group-aware splits.
"""
from __future__ import annotations

from typing import Dict, Sequence

import numpy as np
import pandas as pd
from scipy import stats


def mean_sd_ci(x: Sequence[float], alpha: float = 0.05) -> Dict[str, float]:
    x = np.asarray(x, float)
    n = len(x)
    sd = x.std(ddof=1) if n > 1 else 0.0
    se = sd / np.sqrt(n)
    h = stats.t.ppf(1 - alpha / 2, max(n - 1, 1)) * se
    return {"mean": x.mean(), "sd": sd, "se": se, "ci_low": x.mean() - h, "ci_high": x.mean() + h}


def holm_bonferroni(p: Sequence[float], alpha: float = 0.05):
    """Returns (adjusted p-values, per-rank thresholds alpha/(m-k+1), significant flags), all in the input order."""
    p = np.asarray(p, float)
    m = len(p)
    order = np.argsort(p)
    adj, thr = np.empty(m), np.empty(m)
    running = 0.0
    for rank, idx in enumerate(order):  # rank = k-1
        running = max(running, (m - rank) * p[idx])
        adj[idx] = min(1.0, running)
        thr[idx] = alpha / (m - rank)
    return adj, thr, adj < alpha


def paired_comparison(a: Sequence[float], b: Sequence[float], alpha: float = 0.05) -> Dict[str, float]:
    """Paired t-test of a (proposed) vs b (baseline), effect size d_z = mean(diff)/sd(diff) = t/sqrt(n)."""
    a, b = np.asarray(a, float), np.asarray(b, float)
    d = a - b
    n = len(d)
    t, p = stats.ttest_rel(a, b)
    ci = mean_sd_ci(d, alpha)
    return {"mean_diff": ci["mean"], "sd": ci["sd"], "ci_low": ci["ci_low"], "ci_high": ci["ci_high"], "se": ci["se"], "df": n - 1,
            "t": float(t), "p_raw": float(p), "dz": float(d.mean() / d.std(ddof=1)) if d.std(ddof=1) > 0 else float("inf")}


def compare_to_proposed(scores: Dict[str, Sequence[float]], proposed: str = "ResForge", alpha: float = 0.05) -> pd.DataFrame:
    """One Holm family: ``proposed`` vs every other method in ``scores``."""
    others = [k for k in scores if k != proposed]
    rows = [{"comparison": f"{proposed} vs. {o}", **paired_comparison(scores[proposed], scores[o], alpha)} for o in others]
    df = pd.DataFrame(rows)
    adj, thr, sig = holm_bonferroni(df["p_raw"].values, alpha)
    df["holm_threshold"], df["p_holm"], df["significant"] = thr, adj, sig
    return df
