"""Multi-seed experiment runner implementing the paper's evaluation protocol.

For every seed (the paper uses 20):
  1. group-aware 60/10/30 split;
  2. Stage 1: modified ResNet-18, early stopping on validation loss, threshold tau fitted on the validation split;
  3. Stage 2: improved Mask R-CNN trained on the forged images that have a ground-truth mask, early stopping on validation IoU;
  4. test evaluation: detection metrics, Stage-2 standalone and full-pipeline localisation, false alarms on authentic images;
  5. (optional) baselines under the same split, for the comparison tables and paired statistical tests.
Per-seed results are written to ``<out_dir>/seed<k>/metrics.json`` (runs are resumable) and aggregated as mean +- SD.
"""
from __future__ import annotations

import time
from pathlib import Path
from typing import Dict, List, Optional, Sequence

import numpy as np
import pandas as pd
import torch

from .data.splits import group_split, split_report
from .eval.metrics import best_threshold_by_f1, detection_metrics, evaluate_heatmaps, select_threshold
from .eval.pipeline import evaluate_pipeline
from .models.baselines import build_classifier, build_segmenter
from .models.detector import ResForgeDetector
from .models.localizer import build_maskrcnn
from .train.classifier import predict_probs, train_classifier
from .train.localizer import iter_heatmaps_semantic, train_maskrcnn, train_segmenter, tune_localization_threshold
from .utils import get_device, grid, save_json, seed_everything


def _stage1_kwargs(c):
    return dict(img_size=c.img_size, batch_size=c.batch_size, lr=c.lr, weight_decay=c.weight_decay, optimizer=c.optimizer, epochs=c.epochs,
                patience=c.patience, balanced_sampling=c.balanced_sampling, augment=c.augment, amp=c.amp)


def run_seed(df: pd.DataFrame, root, cfg, seed: int, out_dir: Path, device, run_baselines: bool = False, save_ckpt: bool = False,
             num_workers: int = 0, verbose: bool = True) -> Dict:
    seed_everything(seed)
    s1, s2, sp = cfg.stage1, cfg.stage2, cfg.data.split
    tr, va, te = group_split(df, seed, sp.train, sp.val, sp.test)
    if verbose:
        print(f"[seed {seed}] split\n{split_report(tr, va, te)}")
    out: Dict = {"seed": seed, "split": split_report(tr, va, te).to_dict(orient="index")}

    # ---------------- Stage 1
    det = ResForgeDetector(s1.pretrained, s1.freeze, s1.dropout)
    h1 = train_classifier(det, tr, va, root, device, num_workers=num_workers, verbose=verbose, **_stage1_kwargs(s1))
    pva = predict_probs(det, va, root, s1.img_size, s1.batch_size, device, num_workers, amp=s1.amp)
    thr_cls = select_threshold(va.label.values, pva, grid(s1.threshold_grid))
    out["stage1_threshold"] = thr_cls
    out["stage1_sec_per_epoch"] = float(h1.sec.mean())

    # ---------------- Stage 2
    tr2, va2 = tr[tr.has_mask].reset_index(drop=True), va[va.has_mask].reset_index(drop=True)
    if len(tr2) == 0 or len(va2) == 0:
        raise RuntimeError("No forged images with ground-truth masks in the train/val split; Stage 2 cannot be trained.")
    loc = build_maskrcnn(s2)
    h2 = train_maskrcnn(loc, tr2, va2, root, device, s2, num_workers=num_workers, verbose=verbose)
    thr_loc = tune_localization_threshold(loc, va2, root, s2, device, num_workers) if s2.tune_loc_threshold else s2.loc_threshold
    out["loc_threshold"] = thr_loc
    out["stage2_sec_per_epoch"] = float(h2.sec.mean())
    out.update(evaluate_pipeline(det, loc, te, root, cfg, thr_cls, thr_loc, device, num_workers))
    if verbose:
        print(f"[seed {seed}] detection F1 {out['detection']['f1']:.1f} | loc IoU (standalone) {out['localization_standalone']['iou']:.1f}"
              f" | loc IoU (full pipeline) {out['localization_full_pipeline']['iou']:.1f}")

    # ---------------- baselines
    if run_baselines:
        b = cfg.baselines
        out["baselines_detection"], out["baselines_localization"] = {}, {}
        for name in b.classification:
            if verbose:
                print(f"[seed {seed}] baseline classifier: {name}")
            hp = b.vit if name.startswith("vit") else b.vgg_densenet
            m = build_classifier(name, b.img_size, b.pretrained)
            train_classifier(m, tr, va, root, device, img_size=b.img_size, batch_size=b.batch_size, lr=hp.lr, weight_decay=hp.weight_decay,
                             optimizer=hp.optimizer, epochs=b.epochs, patience=b.patience, balanced_sampling=s1.balanced_sampling,
                             amp=s1.amp, num_workers=num_workers, warmup_epochs=hp.get("warmup_epochs", 0), verbose=False)
            t = select_threshold(va.label.values, predict_probs(m, va, root, b.img_size, b.batch_size, device, num_workers, amp=s1.amp), grid(s1.threshold_grid))
            out["baselines_detection"][name] = detection_metrics(te.label.values, predict_probs(m, te, root, b.img_size, b.batch_size, device, num_workers, amp=s1.amp), t)
            del m
        te2 = te[te.has_mask].reset_index(drop=True)
        for name in b.localization:
            if verbose:
                print(f"[seed {seed}] baseline segmenter: {name}")
            m = build_segmenter(name, b.pretrained)
            train_segmenter(m, tr2, va2, root, device, img_size=b.img_size, batch_size=b.batch_size, lr=b.seg.lr, weight_decay=b.seg.weight_decay,
                            optimizer=b.seg.optimizer, epochs=b.epochs, patience=b.patience, amp=s1.amp, num_workers=num_workers, verbose=False)
            ts = [float(t) for t in grid(s2.loc_threshold_grid)]
            rv = evaluate_heatmaps(iter_heatmaps_semantic(m, va2, root, b.img_size, device, b.batch_size, num_workers=num_workers), ts, compute_auc=False)
            t = best_threshold_by_f1(rv)
            r = evaluate_heatmaps(iter_heatmaps_semantic(m, te2, root, b.img_size, device, b.batch_size, num_workers=num_workers), [t], compute_auc=True)
            out["baselines_localization"][name] = {**r[t], "auc": r["auc"], "threshold": t}
            del m

    d = Path(out_dir) / f"seed{seed}"
    save_json(out, d / "metrics.json")
    if save_ckpt:
        torch.save(det.state_dict(), d / "stage1_resnet18.pt")
        torch.save(loc.state_dict(), d / "stage2_maskrcnn.pt")
        save_json({"stage1_threshold": thr_cls, "loc_threshold": thr_loc}, d / "thresholds.json")
        h1.to_csv(d / "stage1_history.csv", index=False)
        h2.to_csv(d / "stage2_history.csv", index=False)
    return out


def run_experiment(name: str, df: pd.DataFrame, root, cfg, seeds: Optional[Sequence[int]] = None, out_dir: Optional[str | Path] = None,
                   run_baselines: Optional[bool] = None, num_workers: Optional[int] = None, device=None, verbose: bool = True) -> pd.DataFrame:
    """Run (or resume) all seeds for one dataset and return the aggregated tables."""
    device = device or get_device()
    seeds = list(seeds if seeds is not None else range(cfg.data.split.n_runs))
    out_dir = Path(out_dir or Path(cfg.paths.output_dir) / name)
    run_baselines = cfg.experiment.run_baselines if run_baselines is None else run_baselines
    nw = cfg.data.num_workers if num_workers is None else num_workers
    for i, s in enumerate(seeds):
        if (out_dir / f"seed{s}" / "metrics.json").exists():
            print(f"[{name}] seed {s}: found previous results, skipping")
            continue
        t0 = time.time()
        save = cfg.experiment.save_checkpoints == "all" or (cfg.experiment.save_checkpoints == "first" and i == 0)
        run_seed(df, root, cfg, s, out_dir, device, run_baselines, save, nw, verbose)
        print(f"[{name}] seed {s} done in {(time.time() - t0) / 60:.1f} min")
    return aggregate_runs(out_dir)


# ----------------------------------------------------------------------------- aggregation
def load_runs(out_dir: str | Path) -> List[Dict]:
    import json

    return [json.load(open(p)) for p in sorted(Path(out_dir).glob("seed*/metrics.json"), key=lambda p: int(p.parent.name[4:]))]


def runs_table(out_dir: str | Path) -> pd.DataFrame:
    """Long table: one row per (seed, model, task, metric) - the input for the paired statistical tests."""
    rows = []
    for r in load_runs(out_dir):
        s = r["seed"]
        for k, v in r["detection"].items():
            rows.append((s, "ResForge", "detection", k, v))
        for k, v in r["localization_standalone"].items():
            rows.append((s, "ResForge (standalone Stage 2)", "localization", k, v))
        for k, v in r["localization_full_pipeline"].items():
            rows.append((s, "ResForge (full pipeline)", "localization", k, v))
        for m, d in r.get("baselines_detection", {}).items():
            rows += [(s, m, "detection", k, v) for k, v in d.items()]
        for m, d in r.get("baselines_localization", {}).items():
            rows += [(s, m, "localization", k, v) for k, v in d.items()]
    return pd.DataFrame(rows, columns=["seed", "model", "task", "metric", "value"])


def aggregate_runs(out_dir: str | Path) -> pd.DataFrame:
    """Mean +- SD over seeds in the layout of the paper's Tables 3 and 4 (values in %)."""
    t = runs_table(out_dir)
    if t.empty:
        return t
    keep = {"detection": ["precision", "recall", "f1", "auc"], "localization": ["f1", "auc", "iou"]}
    rows = []
    for (task, model), g in t.groupby(["task", "model"], sort=False):
        row = {"task": task, "model": model, "runs": g.seed.nunique()}
        for m in keep[task]:
            v = g[g.metric == m].value.astype(float)
            row[m] = f"{v.mean():.1f} ± {v.std(ddof=1) if len(v) > 1 else 0.0:.1f}"
        rows.append(row)
    return pd.DataFrame(rows)
