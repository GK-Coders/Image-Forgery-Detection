"""Tiny synthetic forgery dataset for smoke-testing the code on any machine (no downloads needed).

Each *parent* image yields one authentic image and one tampered image (copy-move or splicing from another parent)
that share a ``group`` id, mimicking the group structure of the real datasets. The pasted patch is large, strongly colour-tinted and noisy
and therefore easy to spot, so that even a tiny CPU-trained model can pick up the artefact (real forgeries are far subtler). **This is not a benchmark** - numbers obtained on it say
nothing about the paper's results.
"""
from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np
import pandas as pd

from .metadata import COLUMNS


def _base_image(rng: np.random.Generator, size: int) -> np.ndarray:
    low = rng.uniform(0, 255, (size // 16 + 1, size // 16 + 1, 3)).astype(np.float32)
    img = cv2.resize(low, (size, size), interpolation=cv2.INTER_CUBIC)
    for _ in range(rng.integers(4, 9)):
        c = tuple(int(v) for v in rng.integers(0, 255, 3))
        x, y = (int(v) for v in rng.integers(0, size, 2))
        if rng.random() < 0.5:
            cv2.circle(img, (x, y), int(rng.integers(6, size // 6)), c, -1)
        else:
            cv2.rectangle(img, (x, y), (x + int(rng.integers(8, size // 4)), y + int(rng.integers(8, size // 4))), c, -1)
    img = cv2.GaussianBlur(img, (0, 0), 1.2)
    img += rng.normal(0, 3, img.shape)
    return np.clip(img, 0, 255).astype(np.uint8)


def make_synthetic_dataset(root: str | Path, name: str = "synthetic", n_parents: int = 48, size: int = 160, seed: int = 0) -> pd.DataFrame:
    root = Path(root)
    img_dir, mask_dir = root / name / "images", root / name / "masks"
    img_dir.mkdir(parents=True, exist_ok=True)
    mask_dir.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(seed)
    parents = [_base_image(rng, size) for _ in range(n_parents)]
    rows = []
    for i, base in enumerate(parents):
        gid = f"p{i:04d}"
        cv2.imwrite(str(img_dir / f"au_{gid}.jpg"), cv2.cvtColor(base, cv2.COLOR_RGB2BGR), [cv2.IMWRITE_JPEG_QUALITY, 95])
        rows.append(dict(image_path=f"{name}/images/au_{gid}.jpg", mask_path="", label=0, group=gid, dataset=name, forgery_type="authentic"))

        tp = base.copy()
        kind = "copy-move" if rng.random() < 0.5 else "splicing"
        donor = base if kind == "copy-move" else parents[int(rng.integers(0, n_parents))]
        ph, pw = (int(v) for v in rng.integers(size // 4, size // 2, 2))   # ~10% of the image on average
        sy, sx = int(rng.integers(0, size - ph)), int(rng.integers(0, size - pw))
        dy, dx = int(rng.integers(0, size - ph)), int(rng.integers(0, size - pw))
        patch = donor[sy : sy + ph, sx : sx + pw].astype(np.float32)
        tint = np.array([255, 40, 40])[rng.permutation(3)]                                      # strongly saturated tint
        patch = np.clip(0.35 * patch + 0.65 * tint + rng.normal(0, 12, patch.shape), 0, 255).astype(np.uint8)  # visible artefact
        mask = np.zeros((size, size), np.uint8)
        ell = np.zeros((ph, pw), np.uint8)
        cv2.ellipse(ell, (pw // 2, ph // 2), (max(pw // 2 - 1, 1), max(ph // 2 - 1, 1)), 0, 0, 360, 255, -1)
        region = tp[dy : dy + ph, dx : dx + pw]
        region[ell > 0] = patch[ell > 0]
        mask[dy : dy + ph, dx : dx + pw] = ell
        cv2.imwrite(str(img_dir / f"tp_{gid}.jpg"), cv2.cvtColor(tp, cv2.COLOR_RGB2BGR), [cv2.IMWRITE_JPEG_QUALITY, 95])
        cv2.imwrite(str(mask_dir / f"tp_{gid}.png"), mask)
        rows.append(dict(image_path=f"{name}/images/tp_{gid}.jpg", mask_path=f"{name}/masks/tp_{gid}.png", label=1, group=gid, dataset=name, forgery_type=kind))
    df = pd.DataFrame(rows, columns=COLUMNS)
    df.to_csv(root / f"{name}_metadata.csv", index=False)
    return df
