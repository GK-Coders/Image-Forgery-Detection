"""Dataset preparation: raw CASIA v2 / DEFACTO / NIST16 downloads -> unified ``metadata.csv`` + binary masks.

The datasets are *not* redistributable and are not bundled with this repository; see README.md for download links.

CASIA v2   : tampered images carry no masks in the original release. Following the paper, masks are produced by
             pixel-wise subtraction between each tampered image and its authentic background (matched via the file
             name), then resized (nearest), binarised at 127 and median-filtered (3x3). Alternatively the community
             ground-truth release (namtpham/casia2groundtruth, ``*_gt.png``) can be used with ``mask_source='provided'``.
DEFACTO-12k: class-balanced subset (6,000 tampered + their 6,000 MS-COCO authentic parents) built from the full
             DEFACTO release; ``probe_mask`` files are the ground truth.
NIST16     : Nimble Challenge 2016 (needs registration at NIST). Either point to the NC2016 index CSV or provide
             tampered / mask / authentic directories (+ optional probe->base pairing CSV).

All functions return the metadata DataFrame and write it to ``out_csv``.
"""
from __future__ import annotations

import re
import warnings
from pathlib import Path
from typing import Dict, List, Optional

import cv2
import numpy as np
import pandas as pd

from .metadata import COLUMNS

IMG_EXT = {".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp"}


# ----------------------------------------------------------------------------- helpers
def _rel(path: Path, root: Path) -> str:
    """Path relative to ``root`` when possible, otherwise absolute (pathlib joins handle both)."""
    try:
        return str(path.resolve().relative_to(root.resolve()))
    except ValueError:
        return str(path.resolve())


def _write_mask(mask01: np.ndarray, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(dst), (mask01 > 0).astype(np.uint8) * 255)


def _standardise_mask(src: Path, mask_size: int, invert: str | bool = "auto") -> Optional[np.ndarray]:
    """Read a ground-truth mask, resize (nearest), binarise at 127. Foreground must be the minority class."""
    m = cv2.imread(str(src), cv2.IMREAD_GRAYSCALE)
    if m is None:
        return None
    m = cv2.resize(m, (mask_size, mask_size), interpolation=cv2.INTER_NEAREST)
    b = (m > 127).astype(np.uint8)
    if invert == "auto":
        if b.mean() > 0.5:
            b = 1 - b
    elif invert:
        b = 1 - b
    return b


def _save(rows: List[Dict], out_csv: Path) -> pd.DataFrame:
    df = pd.DataFrame(rows, columns=COLUMNS)
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out_csv, index=False)
    return df


# ----------------------------------------------------------------------------- CASIA v2
_TP_RE = re.compile(r"^Tp_([DS])_\w{3}_\w_\w_([a-z]{3})(\d+)_([a-z]{3})(\d+)_(\d+)", re.I)
_AU_RE = re.compile(r"^Au_([a-z]{3})_(\d+)", re.I)


def subtraction_mask(
    au_path: Path,
    tp_path: Path,
    mask_size: int = 512,
    threshold: int = 127,
    normalize_diff: bool = True,
    min_frac: float = 5e-4,
    max_frac: float = 0.9,
) -> Optional[np.ndarray]:
    """Paper Sec. 4.1: pixel-wise subtraction of (authentic, tampered) -> mask at ``mask_size``.

    Returns ``None`` for non-aligned pairs (different size) or ambiguous masks (empty / covering > ``max_frac``).
    ``normalize_diff`` rescales the absolute difference to 0-255 before applying the paper's threshold of 127; the paper
    does not state whether the difference is normalised (see README, "Assumptions").
    """
    a, t = cv2.imread(str(au_path), cv2.IMREAD_COLOR), cv2.imread(str(tp_path), cv2.IMREAD_COLOR)
    if a is None or t is None or a.shape != t.shape:
        return None
    diff = cv2.absdiff(a, t).max(axis=2)
    if normalize_diff and diff.max() > 0:
        diff = (diff.astype(np.float32) / diff.max() * 255).astype(np.uint8)
    diff = cv2.resize(diff, (mask_size, mask_size), interpolation=cv2.INTER_NEAREST)
    m = ((diff > threshold).astype(np.uint8)) * 255
    m = cv2.medianBlur(m, 3)
    frac = float((m > 0).mean())
    if frac < min_frac or frac > max_frac:
        return None
    return (m > 0).astype(np.uint8)


def prepare_casia2(
    casia_root: str | Path,
    out_root: str | Path,
    mask_source: str = "subtraction",
    gt_dir: Optional[str | Path] = None,
    mask_size: int = 512,
    out_csv: Optional[str | Path] = None,
    **sub_kwargs,
) -> pd.DataFrame:
    """``casia_root`` must contain ``Au/`` (authentic) and ``Tp/`` (tampered)."""
    casia_root, out_root = Path(casia_root), Path(out_root)
    out_csv = Path(out_csv or out_root / "casia2_metadata.csv")
    au_dir, tp_dir = casia_root / "Au", casia_root / "Tp"
    if not au_dir.is_dir() or not tp_dir.is_dir():
        raise FileNotFoundError(f"Expected {au_dir} and {tp_dir}")
    if mask_source == "provided" and gt_dir is None:
        raise ValueError("mask_source='provided' needs gt_dir (folder with *_gt.png)")

    au_index: Dict[str, Path] = {}
    rows: List[Dict] = []
    for p in sorted(au_dir.iterdir()):
        m = _AU_RE.match(p.name)
        if p.suffix.lower() in IMG_EXT and m:
            key = f"{m.group(1).lower()}{m.group(2)}"
            au_index[key] = p
            rows.append(dict(image_path=_rel(p, out_root), mask_path="", label=0, group=key, dataset="casia2", forgery_type="authentic"))

    n_total = n_nomatch = n_bad = 0
    for p in sorted(tp_dir.iterdir()):
        m = _TP_RE.match(p.name)
        if p.suffix.lower() not in IMG_EXT or not m:
            continue
        n_total += 1
        kind = "splicing" if m.group(1).upper() == "D" else "copy-move"
        key = f"{m.group(2).lower()}{m.group(3)}"  # background image = first id in the file name
        mask_rel = ""
        mask_dst = out_root / "masks" / "casia2" / f"{p.stem}.png"
        if mask_source == "subtraction":
            au = au_index.get(key)
            if au is None:
                n_nomatch += 1
            else:
                mk = subtraction_mask(au, p, mask_size, **sub_kwargs)
                if mk is None:
                    n_bad += 1
                else:
                    _write_mask(mk, mask_dst)
                    mask_rel = _rel(mask_dst, out_root)
        else:
            gt = Path(gt_dir) / f"{p.stem}_gt.png"
            mk = _standardise_mask(gt, mask_size, invert=False) if gt.exists() else None
            if mk is None or mk.sum() == 0:
                n_bad += 1
            else:
                _write_mask(mk, mask_dst)
                mask_rel = _rel(mask_dst, out_root)
        rows.append(dict(image_path=_rel(p, out_root), mask_path=mask_rel, label=1, group=key, dataset="casia2", forgery_type=kind))

    df = _save(rows, out_csv)
    print(
        f"[casia2] authentic={int((df.label == 0).sum())} tampered={n_total} "
        f"(no authentic match: {n_nomatch}, non-aligned/ambiguous/missing mask: {n_bad}) "
        f"-> usable masks: {int((df.mask_path != '').sum())}\n[casia2] wrote {out_csv}"
    )
    return df


# ----------------------------------------------------------------------------- DEFACTO-12k
_COCO_ID = re.compile(r"(\d{6,12})")
_DEFACTO_TYPES = ("splicing", "copymove", "inpainting")


def _coco_id(name: str) -> Optional[int]:
    m = _COCO_ID.search(name)
    return int(m.group(1)) if m else None


def prepare_defacto12k(
    defacto_root: str | Path,
    coco_dir: str | Path,
    out_root: str | Path,
    n_tampered: int = 6000,
    mask_size: int = 512,
    seed: int = 0,
    out_csv: Optional[str | Path] = None,
) -> pd.DataFrame:
    """Builds the class-balanced DEFACTO-12k subset (n_tampered tampered + the same number of MS-COCO parents).

    ``defacto_root``: the extracted DEFACTO release (folders ``splicing``, ``copymove``, ``inpainting`` ...; each tampered
    image lives in an ``img`` folder, its ground truth in a sibling ``probe_mask`` folder).
    ``coco_dir``:     folder with the original MS-COCO images (``train2014`` / ``val2014`` ... searched recursively).
    The tampered image and its parent are linked through the COCO id contained in the DEFACTO file name.
    """
    defacto_root, coco_dir, out_root = Path(defacto_root), Path(coco_dir), Path(out_root)
    out_csv = Path(out_csv or out_root / "defacto12k_metadata.csv")
    rng = np.random.default_rng(seed)

    coco = {}
    for p in coco_dir.rglob("*"):
        if p.suffix.lower() in IMG_EXT:
            cid = _coco_id(p.stem)
            if cid is not None:
                coco.setdefault(cid, p)
    if not coco:
        raise FileNotFoundError(f"No MS-COCO images found under {coco_dir}")

    masks: Dict[str, Path] = {}
    for p in defacto_root.rglob("*"):
        if p.suffix.lower() in IMG_EXT and p.parent.name == "probe_mask":
            masks[p.stem] = p
    per_type: Dict[str, List[tuple]] = {t: [] for t in _DEFACTO_TYPES}
    for p in defacto_root.rglob("*"):
        if p.suffix.lower() not in IMG_EXT or p.parent.name != "img":
            continue
        parts = [s.lower() for s in p.parts]
        kind = next((t for t in _DEFACTO_TYPES if any(t in s for s in parts)), None)
        cid = _coco_id(p.stem)
        mk = masks.get(p.stem)
        if kind and cid in coco and mk is not None:
            per_type[kind].append((cid, p, mk))
    if not any(per_type.values()):
        raise FileNotFoundError(
            "No (img, probe_mask, COCO parent) triples found. Check the DEFACTO folder layout and that the COCO id "
            "in the DEFACTO file names matches the COCO file names (see README)."
        )

    # one tampered image per COCO parent, equal share per forgery type where possible
    chosen, used = [], set()
    share = n_tampered // len(_DEFACTO_TYPES)
    leftovers = []
    for t, items in per_type.items():
        order = rng.permutation(len(items))
        take = 0
        for j in order:
            cid, p, mk = items[j]
            if cid in used:
                continue
            if take < share:
                chosen.append((t, cid, p, mk)); used.add(cid); take += 1
            else:
                leftovers.append((t, cid, p, mk))
    for item in leftovers:
        if len(chosen) >= n_tampered:
            break
        if item[1] not in used:
            chosen.append(item); used.add(item[1])
    if len(chosen) < n_tampered:
        warnings.warn(f"Only {len(chosen)} tampered images with unique COCO parents were found (wanted {n_tampered}).")

    rows: List[Dict] = []
    for t, cid, p, mk in chosen:
        m = _standardise_mask(mk, mask_size, invert=False)
        if m is None or m.sum() == 0:
            continue
        dst = out_root / "masks" / "defacto12k" / f"{p.stem}.png"
        _write_mask(m, dst)
        kind = "removal(inpainting)" if t == "inpainting" else ("copy-move" if t == "copymove" else "splicing")
        rows.append(dict(image_path=_rel(p, out_root), mask_path=_rel(dst, out_root), label=1, group=str(cid), dataset="defacto12k", forgery_type=kind))
        rows.append(dict(image_path=_rel(coco[cid], out_root), mask_path="", label=0, group=str(cid), dataset="defacto12k", forgery_type="authentic"))
    df = _save(rows, out_csv)
    print(f"[defacto12k] tampered={int((df.label == 1).sum())} authentic={int((df.label == 0).sum())}\n[defacto12k] wrote {out_csv}")
    return df


# ----------------------------------------------------------------------------- NIST16
def _first_col(df: pd.DataFrame, names) -> Optional[str]:
    low = {c.lower(): c for c in df.columns}
    for n in names:
        if n.lower() in low:
            return low[n.lower()]
    return None


def prepare_nist16(
    out_root: str | Path,
    nc_root: Optional[str | Path] = None,
    index_csv: Optional[str | Path] = None,
    tampered_dir: Optional[str | Path] = None,
    mask_dir: Optional[str | Path] = None,
    authentic_dir: Optional[str | Path] = None,
    pairs_csv: Optional[str | Path] = None,
    mask_size: int = 512,
    invert_masks: str | bool = "auto",
    out_csv: Optional[str | Path] = None,
) -> pd.DataFrame:
    """Builds NIST16 metadata. Two ways to describe the raw data:

    (a) ``nc_root`` + ``index_csv``: NC2016 reference index with columns ProbeFileName, BaseFileName, ProbeMaskFileName
        (names matched case-insensitively; paths relative to ``nc_root``). Base (reference) images become the authentic
        class, and ``group`` = base image id.
    (b) ``tampered_dir`` + ``mask_dir`` (+ ``authentic_dir``, + ``pairs_csv`` with columns probe,base): file stems are
        matched between images and masks.

    The NC2016 release layout is only available to registered users, so this function could not be tested against the
    real release; if your copy is organised differently, build the metadata CSV yourself (see docs in
    ``resforge/data/metadata.py``) - everything downstream only needs that CSV.
    """
    out_root = Path(out_root)
    out_csv = Path(out_csv or out_root / "nist16_metadata.csv")
    rows: List[Dict] = []
    seen_auth: set = set()

    def add_mask(src: Path, stem: str) -> str:
        m = _standardise_mask(src, mask_size, invert=invert_masks)
        if m is None or m.sum() == 0:
            return ""
        dst = out_root / "masks" / "nist16" / f"{stem}.png"
        _write_mask(m, dst)
        return _rel(dst, out_root)

    if index_csv is not None:
        if nc_root is None:
            raise ValueError("nc_root is required with index_csv")
        nc_root = Path(nc_root)
        idx = pd.read_csv(index_csv, sep=None, engine="python")
        c_probe = _first_col(idx, ["ProbeFileName", "probe", "probe_file"])
        c_base = _first_col(idx, ["BaseFileName", "base", "base_file"])
        c_mask = _first_col(idx, ["ProbeMaskFileName", "mask", "mask_file"])
        if not (c_probe and c_base and c_mask):
            raise ValueError(f"Could not find probe/base/mask columns in {list(idx.columns)}")
        for _, r in idx.iterrows():
            probe, base, mk = nc_root / str(r[c_probe]), nc_root / str(r[c_base]), nc_root / str(r[c_mask])
            if not probe.exists() or str(r[c_base]) in ("", "nan"):
                continue
            gid = Path(str(r[c_base])).stem
            rows.append(dict(image_path=_rel(probe, out_root), mask_path=add_mask(mk, probe.stem) if mk.exists() else "", label=1, group=gid, dataset="nist16", forgery_type=""))
            if base.exists() and gid not in seen_auth:
                seen_auth.add(gid)
                rows.append(dict(image_path=_rel(base, out_root), mask_path="", label=0, group=gid, dataset="nist16", forgery_type="authentic"))
    else:
        if tampered_dir is None or mask_dir is None:
            raise ValueError("Provide (nc_root, index_csv) or (tampered_dir, mask_dir)")
        tampered_dir, mask_dir = Path(tampered_dir), Path(mask_dir)
        pairs: Dict[str, str] = {}
        if pairs_csv is not None:
            pc = pd.read_csv(pairs_csv)
            pairs = {Path(str(a)).stem: Path(str(b)).stem for a, b in zip(pc["probe"], pc["base"])}
        else:
            warnings.warn("No pairs_csv: every image is its own group, so a probe and its base image may land in different partitions (leakage).")
        masks = {p.stem.replace("_mask", "").replace("_gt", ""): p for p in mask_dir.iterdir() if p.suffix.lower() in IMG_EXT}
        for p in sorted(tampered_dir.iterdir()):
            if p.suffix.lower() not in IMG_EXT:
                continue
            gid = pairs.get(p.stem, p.stem)
            mk = masks.get(p.stem)
            rows.append(dict(image_path=_rel(p, out_root), mask_path=add_mask(mk, p.stem) if mk else "", label=1, group=gid, dataset="nist16", forgery_type=""))
        if authentic_dir is not None:
            for p in sorted(Path(authentic_dir).iterdir()):
                if p.suffix.lower() in IMG_EXT:
                    rows.append(dict(image_path=_rel(p, out_root), mask_path="", label=0, group=p.stem, dataset="nist16", forgery_type="authentic"))
    df = _save(rows, out_csv)
    print(f"[nist16] authentic={int((df.label == 0).sum())} tampered={int((df.label == 1).sum())} with_mask={int((df.mask_path != '').sum())}\n[nist16] wrote {out_csv}")
    return df
