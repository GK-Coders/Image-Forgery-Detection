"""Group-aware 60/10/30 splits (paper Sec. 3.1).

``GroupShuffleSplit`` keeps every derivative of one authentic parent image in the same partition, so validation and
test sets only contain backgrounds that were never seen in training. The whole protocol is repeated for 20 seeds.
"""
from __future__ import annotations

from typing import Tuple

import pandas as pd
from sklearn.model_selection import GroupShuffleSplit


def group_split(
    df: pd.DataFrame, seed: int, train: float = 0.6, val: float = 0.1, test: float = 0.3
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    assert abs(train + val + test - 1.0) < 1e-6
    groups = df["group"].values
    outer = GroupShuffleSplit(n_splits=1, test_size=test, random_state=seed)
    trval_idx, test_idx = next(outer.split(df, df["label"], groups))
    trval = df.iloc[trval_idx]
    inner = GroupShuffleSplit(n_splits=1, test_size=val / (train + val), random_state=seed)
    tr_idx, va_idx = next(inner.split(trval, trval["label"], trval["group"].values))
    tr, va, te = trval.iloc[tr_idx], trval.iloc[va_idx], df.iloc[test_idx]
    for a, b in [(tr, va), (tr, te), (va, te)]:
        assert set(a.group).isdisjoint(set(b.group)), "group leakage between partitions"
    return tr.reset_index(drop=True), va.reset_index(drop=True), te.reset_index(drop=True)


def split_report(tr: pd.DataFrame, va: pd.DataFrame, te: pd.DataFrame) -> pd.DataFrame:
    rows = {}
    for name, d in [("train", tr), ("val", va), ("test", te)]:
        rows[name] = {
            "images": len(d),
            "authentic": int((d.label == 0).sum()),
            "forged": int((d.label == 1).sum()),
            "forged_with_mask": int(d.has_mask.sum()),
            "groups": d.group.nunique(),
        }
    return pd.DataFrame(rows).T
