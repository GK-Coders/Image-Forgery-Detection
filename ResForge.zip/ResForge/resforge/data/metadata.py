"""Unified metadata schema shared by all three datasets.

Every dataset is converted to one CSV with the columns

    image_path   path relative to ``data_root``
    mask_path    path relative to ``data_root`` ('' for authentic images or tampered images without a valid mask)
    label        0 = authentic, 1 = forged
    group        parent-image id; all derivatives of one authentic source share a group (used for leakage-free splits)
    dataset      casia2 | defacto12k | nist16
    forgery_type optional free text (splicing / copy-move / inpainting ...)

so the rest of the pipeline is dataset-agnostic.
"""
from __future__ import annotations

from pathlib import Path

import pandas as pd

COLUMNS = ["image_path", "mask_path", "label", "group", "dataset", "forgery_type"]


def load_metadata(csv_path: str | Path) -> pd.DataFrame:
    df = pd.read_csv(csv_path, keep_default_na=False)
    missing = set(COLUMNS[:5]) - set(df.columns)
    if missing:
        raise ValueError(f"{csv_path}: missing columns {sorted(missing)}")
    if "forgery_type" not in df.columns:
        df["forgery_type"] = ""
    df["label"] = df["label"].astype(int)
    df["group"] = df["group"].astype(str)
    df["mask_path"] = df["mask_path"].astype(str)
    df["has_mask"] = (df["label"] == 1) & (df["mask_path"].str.len() > 0)
    return df


def check_files(df: pd.DataFrame, root: str | Path, max_report: int = 5) -> None:
    """Raise if image/mask files listed in the metadata do not exist."""
    root = Path(root)
    bad = [p for p in df["image_path"] if not (root / p).exists()]
    bad += [p for p in df.loc[df.has_mask, "mask_path"] if not (root / p).exists()]
    if bad:
        raise FileNotFoundError(f"{len(bad)} files listed in metadata are missing under {root}, e.g. {bad[:max_report]}")


def summarize(df: pd.DataFrame) -> pd.DataFrame:
    """Counts per class, with number of groups and forged images that have a usable mask."""
    return pd.DataFrame(
        {
            "images": [len(df), (df.label == 0).sum(), (df.label == 1).sum()],
            "groups": [df.group.nunique(), df.loc[df.label == 0, "group"].nunique(), df.loc[df.label == 1, "group"].nunique()],
            "with_mask": [int(df.has_mask.sum()), 0, int(df.has_mask.sum())],
        },
        index=["all", "authentic", "forged"],
    )
