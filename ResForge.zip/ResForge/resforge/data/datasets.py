"""Torch datasets: image-level classification and pixel-level segmentation/detection.

Images are always read as RGB uint8, resized with bilinear interpolation to the model resolution, optionally degraded by
a ``perturb`` callable (robustness study, applied *after* resizing), and then converted to tensors.
Masks are resized with nearest-neighbour interpolation and binarised (paper Sec. 4.1).
"""
from __future__ import annotations

from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

import cv2
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset

IMAGENET_MEAN = np.array([0.485, 0.456, 0.406], dtype=np.float32)
IMAGENET_STD = np.array([0.229, 0.224, 0.225], dtype=np.float32)

Perturb = Optional[Callable[[np.ndarray], np.ndarray]]


def load_rgb(path: str | Path, size: int) -> np.ndarray:
    img = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if img is None:
        raise FileNotFoundError(path)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    return cv2.resize(img, (size, size), interpolation=cv2.INTER_LINEAR)


def load_mask(path: str | Path, size: int) -> np.ndarray:
    m = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
    if m is None:
        raise FileNotFoundError(path)
    m = cv2.resize(m, (size, size), interpolation=cv2.INTER_NEAREST)
    return (m > 127).astype(np.uint8)


def to_tensor01(img: np.ndarray) -> torch.Tensor:
    return torch.from_numpy(np.ascontiguousarray(img)).permute(2, 0, 1).float() / 255.0


def normalize(t: torch.Tensor) -> torch.Tensor:
    mean = torch.tensor(IMAGENET_MEAN, device=t.device).view(1, 3, 1, 1)
    std = torch.tensor(IMAGENET_STD, device=t.device).view(1, 3, 1, 1)
    return (t - mean) / std


class ClsDataset(Dataset):
    """(normalised image, label) for forged/authentic classification."""

    def __init__(self, df: pd.DataFrame, root: str | Path, img_size: int, augment: bool = False, perturb: Perturb = None):
        self.df, self.root, self.size, self.augment, self.perturb = df.reset_index(drop=True), Path(root), img_size, augment, perturb

    def __len__(self) -> int:
        return len(self.df)

    def __getitem__(self, i: int):
        r = self.df.iloc[i]
        img = load_rgb(self.root / r.image_path, self.size)
        if self.perturb is not None:
            img = self.perturb(img)
        if self.augment and np.random.rand() < 0.5:
            img = img[:, ::-1]
        x = normalize(to_tensor01(img).unsqueeze(0))[0]
        return x, torch.tensor(float(r.label))


class SegDataset(Dataset):
    """(image in [0,1], binary mask uint8 HxW). Rows without a mask (authentic images) get an all-zero mask when
    ``allow_no_mask=True``; otherwise only forged rows with a usable mask are accepted."""

    def __init__(self, df: pd.DataFrame, root: str | Path, img_size: int, augment: bool = False, perturb: Perturb = None,
                 allow_no_mask: bool = False):
        df = df.reset_index(drop=True)
        assert allow_no_mask or df.has_mask.all(), "SegDataset expects forged rows with masks only"
        self.df, self.root, self.size, self.augment, self.perturb = df, Path(root), img_size, augment, perturb

    def __len__(self) -> int:
        return len(self.df)

    def __getitem__(self, i: int):
        r = self.df.iloc[i]
        img = load_rgb(self.root / r.image_path, self.size)
        mask = load_mask(self.root / r.mask_path, self.size) if r.has_mask else np.zeros((self.size, self.size), np.uint8)
        if self.perturb is not None:
            img = self.perturb(img)
        if self.augment and np.random.rand() < 0.5:
            img, mask = img[:, ::-1], mask[:, ::-1]
        return to_tensor01(img), torch.from_numpy(np.ascontiguousarray(mask))


def list_collate(batch):
    xs, ys = zip(*batch)
    return list(xs), list(ys)


def mask_to_target(mask: np.ndarray, min_area: int = 16, max_instances: int = 20) -> Dict[str, torch.Tensor]:
    """Binary mask -> Mask R-CNN target. Every 8-connected component becomes one 'forged' instance."""
    n, lab, stats, _ = cv2.connectedComponentsWithStats(mask.astype(np.uint8), connectivity=8)
    comps = sorted(((int(stats[i, cv2.CC_STAT_AREA]), i) for i in range(1, n) if stats[i, cv2.CC_STAT_AREA] >= min_area), reverse=True)
    comps = comps[:max_instances]
    h, w = mask.shape
    if not comps:
        return {
            "boxes": torch.zeros((0, 4), dtype=torch.float32),
            "labels": torch.zeros((0,), dtype=torch.int64),
            "masks": torch.zeros((0, h, w), dtype=torch.uint8),
        }
    boxes, masks = [], []
    for _, i in comps:
        x, y, bw, bh = (int(stats[i, k]) for k in (cv2.CC_STAT_LEFT, cv2.CC_STAT_TOP, cv2.CC_STAT_WIDTH, cv2.CC_STAT_HEIGHT))
        boxes.append([x, y, x + max(bw, 1), y + max(bh, 1)])
        masks.append((lab == i).astype(np.uint8))
    return {
        "boxes": torch.tensor(boxes, dtype=torch.float32),
        "labels": torch.ones(len(boxes), dtype=torch.int64),
        "masks": torch.from_numpy(np.stack(masks)),
    }
