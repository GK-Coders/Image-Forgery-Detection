"""Plot helpers used by the notebooks."""
from __future__ import annotations

from pathlib import Path
from typing import Dict, Sequence

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .data.datasets import load_mask, load_rgb


def show_samples(df: pd.DataFrame, root, n: int = 4, size: int = 256, seed: int = 0):
    """Forged images with their ground-truth mask overlay, next to authentic examples."""
    rng = np.random.default_rng(seed)
    forged = df[df.has_mask]
    pick = forged.iloc[rng.choice(len(forged), min(n, len(forged)), replace=False)]
    fig, ax = plt.subplots(2, len(pick), figsize=(3 * len(pick), 6), squeeze=False)
    for j, (_, r) in enumerate(pick.iterrows()):
        img, m = load_rgb(Path(root) / r.image_path, size), load_mask(Path(root) / r.mask_path, size)
        ax[0, j].imshow(img); ax[0, j].set_title(f"forged ({r.forgery_type})", fontsize=9)
        ax[1, j].imshow(img); ax[1, j].imshow(np.ma.masked_where(m == 0, m), cmap="autumn", alpha=0.6); ax[1, j].set_title("GT mask", fontsize=9)
    for a in ax.ravel():
        a.axis("off")
    plt.tight_layout()
    return fig


def plot_history(hist: pd.DataFrame, cols: Sequence[str], title: str = ""):
    fig, ax = plt.subplots(figsize=(5, 3.2))
    for c in cols:
        ax.plot(hist.epoch, hist[c], marker="o", label=c)
    ax.set_xlabel("epoch"); ax.set_title(title); ax.legend(); ax.grid(alpha=0.3)
    plt.tight_layout()
    return fig


def plot_roc(curves: Dict[str, tuple], title: str = "Image-level ROC"):
    fig, ax = plt.subplots(figsize=(4.2, 4))
    for name, (fpr, tpr, auc) in curves.items():
        ax.plot(fpr, tpr, label=f"{name} (AUC {auc:.1f})")
    ax.plot([0, 1], [0, 1], "k--", lw=0.8)
    ax.set_xlabel("False positive rate"); ax.set_ylabel("True positive rate"); ax.set_title(title); ax.legend(fontsize=8); ax.grid(alpha=0.3)
    plt.tight_layout()
    return fig


def show_predictions(rows: Sequence[tuple], thr: float):
    """rows: (image uint8 HxWx3, gt HxW, heat HxW). Columns: image | ground truth | heat-map | binary prediction (cf. paper Fig. 5)."""
    fig, ax = plt.subplots(len(rows), 4, figsize=(10, 2.5 * len(rows)), squeeze=False)
    for i, (img, gt, heat) in enumerate(rows):
        ax[i, 0].imshow(img); ax[i, 1].imshow(gt, cmap="gray", vmin=0, vmax=1)
        ax[i, 2].imshow(heat, cmap="jet", vmin=0, vmax=1); ax[i, 3].imshow(heat >= thr, cmap="gray", vmin=0, vmax=1)
        if i == 0:
            for j, t in enumerate(["input", "ground truth", "heat-map", f"prediction (t={thr:.2f})"]):
                ax[i, j].set_title(t, fontsize=9)
    for a in ax.ravel():
        a.axis("off")
    plt.tight_layout()
    return fig


def plot_robustness(df: pd.DataFrame, title: str = "Pixel-level F1 under post-processing"):
    piv = df.pivot(index="condition", columns="model", values="pixel_f1").reindex(df.condition.unique())
    ax = piv.plot(kind="bar", figsize=(9, 3.8), width=0.8)
    ax.set_ylabel("pixel F1 (%)"); ax.set_title(title); ax.grid(axis="y", alpha=0.3); plt.xticks(rotation=25, ha="right"); plt.tight_layout()
    return ax.figure
