"""Shared notebook setup. ``init()`` returns config, device, metadata and data root in one call."""
from __future__ import annotations

import os
from pathlib import Path
from types import SimpleNamespace
from typing import Optional

from .config import REPO_ROOT, load_config
from .data.metadata import check_files, load_metadata
from .data.synthetic import make_synthetic_dataset
from .utils import get_device, seed_everything

DATASETS = ("casia2", "defacto12k", "nist16")


def demo_mode() -> bool:
    """Set ``RESFORGE_DEMO=1`` before launching Jupyter to run any notebook on tiny synthetic data (CPU, minutes)."""
    return os.environ.get("RESFORGE_DEMO", "0") == "1"


def init(dataset: str = "casia2", demo: Optional[bool] = None, overrides: Optional[dict] = None, need_data: bool = True) -> SimpleNamespace:
    demo = demo_mode() if demo is None else demo
    os.chdir(REPO_ROOT)
    cfg = load_config("configs/demo.yaml" if demo else None, overrides)
    if demo:
        dataset = "synthetic"
    root = Path(cfg.paths.data_root)
    csv = root / f"{dataset}_metadata.csv"
    df = None
    if demo and not csv.exists():
        make_synthetic_dataset(root, "synthetic", n_parents=96, size=128)
    if need_data:
        if not csv.exists():
            raise FileNotFoundError(f"{csv} not found. Run notebook 01 (or scripts/prepare_data.py) first, or set RESFORGE_DEMO=1.")
        df = load_metadata(csv)
        check_files(df, root)
    seed_everything(cfg.seed)
    dev = get_device()
    print(f"dataset={dataset} | demo={demo} | device={dev} | data_root={root}")
    if demo:
        print("DEMO MODE: synthetic data + tiny settings. Numbers are NOT comparable to the paper.")
    return SimpleNamespace(cfg=cfg, device=dev, demo=demo, dataset=dataset, df=df, root=root, csv=csv)
