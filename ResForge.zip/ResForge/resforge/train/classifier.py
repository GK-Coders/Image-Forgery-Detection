"""Training / inference for image-level classifiers (ResForge Stage 1 and the detection baselines)."""
from __future__ import annotations

import time
from pathlib import Path
from typing import Callable, Optional

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, WeightedRandomSampler

from ..data.datasets import ClsDataset
from ..utils import EarlyStopping


def _loader(df, root, img_size, batch_size, train, balanced, num_workers, augment, perturb=None):
    ds = ClsDataset(df, root, img_size, augment=augment and train, perturb=perturb)
    if train and balanced:
        y = df["label"].values.astype(int)
        w = 1.0 / np.bincount(y, minlength=2)[y]  # balanced mini-batch sampling: each class equally likely
        sampler = WeightedRandomSampler(torch.tensor(w, dtype=torch.double), num_samples=len(df), replacement=True)
        return DataLoader(ds, batch_size=batch_size, sampler=sampler, num_workers=num_workers, drop_last=len(df) > batch_size)
    return DataLoader(ds, batch_size=batch_size, shuffle=train, num_workers=num_workers, drop_last=train and len(df) > batch_size)


@torch.no_grad()
def predict_probs(model: nn.Module, df: pd.DataFrame, root, img_size: int, batch_size: int, device, num_workers: int = 0,
                  perturb: Optional[Callable] = None, amp: bool = False) -> np.ndarray:
    """p_forged for every row of ``df`` (sigmoid of the single logit)."""
    model.eval().to(device)
    out = []
    for x, _ in _loader(df, root, img_size, batch_size, False, False, num_workers, False, perturb):
        with torch.autocast(device.type, enabled=amp and device.type == "cuda"):
            out.append(torch.sigmoid(model(x.to(device))).float().cpu())
    return torch.cat(out).numpy()


def train_classifier(
    model: nn.Module,
    tr_df: pd.DataFrame,
    va_df: pd.DataFrame,
    root,
    device,
    *,
    img_size: int,
    batch_size: int,
    lr: float,
    weight_decay: float,
    optimizer: str = "adam",
    epochs: int = 50,
    patience: int = 10,
    balanced_sampling: bool = True,
    augment: bool = False,
    amp: bool = False,
    num_workers: int = 0,
    warmup_epochs: int = 0,
    verbose: bool = True,
) -> pd.DataFrame:
    """BCE loss, early stopping on validation loss, best weights restored. Returns the per-epoch history."""
    model.to(device)
    params = [p for p in model.parameters() if p.requires_grad]
    opt = (torch.optim.AdamW if optimizer == "adamw" else torch.optim.Adam)(params, lr=lr, weight_decay=weight_decay)
    lossf = nn.BCEWithLogitsLoss()
    use_amp = amp and device.type == "cuda"
    scaler = torch.amp.GradScaler(enabled=use_amp)
    tr_loader = _loader(tr_df, root, img_size, batch_size, True, balanced_sampling, num_workers, augment)
    va_loader = _loader(va_df, root, img_size, batch_size, False, False, num_workers, False)
    es, hist = EarlyStopping(patience, "min"), []
    for ep in range(epochs):
        if warmup_epochs and ep < warmup_epochs:
            for g in opt.param_groups:
                g["lr"] = lr * (ep + 1) / warmup_epochs
        t0 = time.time()
        model.train()
        tl, n = 0.0, 0
        for x, y in tr_loader:
            x, y = x.to(device), y.to(device)
            opt.zero_grad(set_to_none=True)
            with torch.autocast(device.type, enabled=use_amp):
                loss = lossf(model(x).float(), y)
            scaler.scale(loss).backward()
            scaler.step(opt)
            scaler.update()
            tl += loss.item() * len(y); n += len(y)
        model.eval()
        vl, vn, correct = 0.0, 0, 0
        with torch.no_grad():
            for x, y in va_loader:
                x, y = x.to(device), y.to(device)
                with torch.autocast(device.type, enabled=use_amp):
                    lg = model(x).float()
                vl += lossf(lg, y).item() * len(y); vn += len(y)
                correct += ((lg > 0).float() == y).sum().item()
        row = dict(epoch=ep + 1, train_loss=tl / max(n, 1), val_loss=vl / max(vn, 1), val_acc=correct / max(vn, 1), sec=time.time() - t0)
        hist.append(row)
        if verbose:
            print(f"  ep {ep + 1:3d} | train {row['train_loss']:.4f} | val {row['val_loss']:.4f} | val acc {row['val_acc']:.3f} | {row['sec']:.0f}s")
        if es.step(row["val_loss"], model, ep + 1):
            if verbose:
                print(f"  early stop (best epoch {es.best_epoch})")
            break
    es.restore(model)
    return pd.DataFrame(hist)
