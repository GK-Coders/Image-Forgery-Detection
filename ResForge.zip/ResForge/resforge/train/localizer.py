"""Training / inference for localisation models: improved Mask R-CNN (Stage 2) and the segmentation baselines."""
from __future__ import annotations

import time
from typing import Callable, Dict, Iterator, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from ..data.datasets import SegDataset, list_collate, mask_to_target
from ..eval.metrics import best_threshold_by_f1, evaluate_heatmaps
from ..models.localizer import weighted_loss
from ..utils import EarlyStopping

Heat = Tuple[np.ndarray, np.ndarray]


# ----------------------------------------------------------------------------- inference iterators -> (heat, gt)
@torch.no_grad()
def iter_heatmaps_maskrcnn(model, df, root, img_size, device, batch_size: int = 4, perturb: Optional[Callable] = None,
                           heatmap_mode: str = "score_x_mask", num_workers: int = 0, allow_no_mask: bool = False) -> Iterator[Heat]:
    """Continuous heat-map = per-pixel maximum over all instance predictions (paper Sec. 4.3, pixel-AUC paragraph)."""
    model.eval().to(device)
    loader = DataLoader(SegDataset(df, root, img_size, perturb=perturb, allow_no_mask=allow_no_mask), batch_size=batch_size,
                        collate_fn=list_collate, num_workers=num_workers)
    for imgs, masks in loader:
        outs = model([i.to(device) for i in imgs])
        for o, m in zip(outs, masks):
            if len(o["scores"]) == 0:
                heat = np.zeros((img_size, img_size), np.float32)
            else:
                mp = o["masks"][:, 0]
                if heatmap_mode == "score_x_mask":
                    mp = mp * o["scores"].view(-1, 1, 1)
                heat = mp.max(0).values.float().cpu().numpy()
            yield heat, m.numpy()


@torch.no_grad()
def iter_heatmaps_semantic(model, df, root, img_size, device, batch_size: int = 8, perturb: Optional[Callable] = None,
                           num_workers: int = 0) -> Iterator[Heat]:
    model.eval().to(device)
    loader = DataLoader(SegDataset(df, root, img_size, perturb=perturb), batch_size=batch_size, collate_fn=list_collate, num_workers=num_workers)
    for imgs, masks in loader:
        prob = torch.sigmoid(model(torch.stack(imgs).to(device)))[:, 0].float().cpu().numpy()
        for p, m in zip(prob, masks):
            yield p, m.numpy()


# ----------------------------------------------------------------------------- Mask R-CNN training
def train_maskrcnn(model: nn.Module, tr_df: pd.DataFrame, va_df: pd.DataFrame, root, device, cfg2, num_workers: int = 0,
                   verbose: bool = True) -> pd.DataFrame:
    """AdamW, weighted multi-task loss (Eq. 3), early stopping on validation mean IoU (threshold 0.5), best weights restored."""
    model.to(device)
    params = [p for p in model.parameters() if p.requires_grad]
    opt = torch.optim.AdamW(params, lr=cfg2.lr, weight_decay=cfg2.weight_decay)
    micro = min(cfg2.micro_batch_size, cfg2.batch_size)
    accum = max(1, cfg2.batch_size // micro)
    use_amp = cfg2.amp and device.type == "cuda"
    scaler = torch.amp.GradScaler(enabled=use_amp)
    loader = DataLoader(SegDataset(tr_df, root, cfg2.img_size, augment=cfg2.augment), batch_size=micro, shuffle=True,
                        collate_fn=list_collate, num_workers=num_workers)
    es, hist = EarlyStopping(cfg2.patience, "max"), []
    for ep in range(cfg2.epochs):
        t0 = time.time()
        model.train()
        tot, n = 0.0, 0
        opt.zero_grad(set_to_none=True)
        for step, (imgs, masks) in enumerate(loader):
            imgs = [i.to(device) for i in imgs]
            targets = [{k: v.to(device) for k, v in mask_to_target(m.numpy(), cfg2.min_instance_area, cfg2.max_instances).items()} for m in masks]
            with torch.autocast(device.type, enabled=use_amp):
                loss = weighted_loss(model(imgs, targets), cfg2.loss_weights)
            scaler.scale(loss / accum).backward()
            if (step + 1) % accum == 0 or step + 1 == len(loader):
                scaler.step(opt); scaler.update(); opt.zero_grad(set_to_none=True)
            tot += loss.item() * len(imgs); n += len(imgs)
        res = evaluate_heatmaps(
            iter_heatmaps_maskrcnn(model, va_df, root, cfg2.img_size, device, batch_size=micro, heatmap_mode=cfg2.heatmap_mode, num_workers=num_workers),
            thresholds=[0.5], compute_auc=False)
        val_iou = res[0.5]["iou"]
        hist.append(dict(epoch=ep + 1, train_loss=tot / max(n, 1), val_iou=val_iou, sec=time.time() - t0))
        if verbose:
            print(f"  ep {ep + 1:3d} | train loss {hist[-1]['train_loss']:.4f} | val IoU {val_iou:.2f} | {hist[-1]['sec']:.0f}s")
        if es.step(val_iou, model, ep + 1):
            if verbose:
                print(f"  early stop (best epoch {es.best_epoch})")
            break
    es.restore(model)
    return pd.DataFrame(hist)


def tune_localization_threshold(model, va_df, root, cfg2, device, num_workers: int = 0, grid=None) -> float:
    """Pick the binarisation threshold maximising mean pixel-F1 on the validation split."""
    from ..utils import grid as mkgrid

    ts = [float(t) for t in (grid if grid is not None else mkgrid(cfg2.loc_threshold_grid))]
    res = evaluate_heatmaps(
        iter_heatmaps_maskrcnn(model, va_df, root, cfg2.img_size, device, batch_size=min(cfg2.micro_batch_size, 8), heatmap_mode=cfg2.heatmap_mode, num_workers=num_workers),
        thresholds=ts, compute_auc=False)
    return best_threshold_by_f1(res)


# ----------------------------------------------------------------------------- segmentation baselines
def train_segmenter(model: nn.Module, tr_df, va_df, root, device, *, img_size: int, batch_size: int, lr: float, weight_decay: float,
                    optimizer: str = "adam", epochs: int = 50, patience: int = 15, amp: bool = False, num_workers: int = 0,
                    verbose: bool = True) -> pd.DataFrame:
    model.to(device)
    opt = (torch.optim.AdamW if optimizer == "adamw" else torch.optim.Adam)(model.parameters(), lr=lr, weight_decay=weight_decay)
    lossf = nn.BCEWithLogitsLoss()
    use_amp = amp and device.type == "cuda"
    scaler = torch.amp.GradScaler(enabled=use_amp)
    loader = DataLoader(SegDataset(tr_df, root, img_size), batch_size=batch_size, shuffle=True, collate_fn=list_collate, num_workers=num_workers)
    es, hist = EarlyStopping(patience, "max"), []
    for ep in range(epochs):
        t0 = time.time()
        model.train()
        tot, n = 0.0, 0
        for imgs, masks in loader:
            x = torch.stack(imgs).to(device)
            y = torch.stack(masks).float().unsqueeze(1).to(device)
            opt.zero_grad(set_to_none=True)
            with torch.autocast(device.type, enabled=use_amp):
                loss = lossf(model(x).float(), y)
            scaler.scale(loss).backward(); scaler.step(opt); scaler.update()
            tot += loss.item() * len(imgs); n += len(imgs)
        res = evaluate_heatmaps(iter_heatmaps_semantic(model, va_df, root, img_size, device, batch_size, num_workers=num_workers), thresholds=[0.5], compute_auc=False)
        hist.append(dict(epoch=ep + 1, train_loss=tot / max(n, 1), val_iou=res[0.5]["iou"], sec=time.time() - t0))
        if verbose:
            print(f"  ep {ep + 1:3d} | train loss {hist[-1]['train_loss']:.4f} | val IoU {hist[-1]['val_iou']:.2f} | {hist[-1]['sec']:.0f}s")
        if es.step(hist[-1]["val_iou"], model, ep + 1):
            break
    es.restore(model)
    return pd.DataFrame(hist)
