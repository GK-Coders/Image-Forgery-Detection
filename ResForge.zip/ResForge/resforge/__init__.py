"""ResForge: image forgery detection and region localisation with residual feature representation learning.

Reference implementation of the two-stage pipeline described in
"Image Forgery Detection and Region Localization Using Residual Feature Representation Learning"
(Shivakumar et al., IJIES).
"""

__version__ = "1.0.0"

from .config import load_config  # noqa: F401
