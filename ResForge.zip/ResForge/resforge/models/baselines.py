"""Comparison models re-implemented under the paper's unified protocol (Sec. 4).

Detection baselines (image level): VGG-16, DenseNet-121, ViT ("ViT-132" in the paper, interpreted as ViT-B/32).
Localisation baselines (pixel level): U-Net, FCN (FCN-8s on a VGG-16 encoder), SegNet (VGG-16 encoder/decoder with pooling indices).

The literature methods of Tables 9-10 (SSR-IFL, FreNet, AFCMS-Net, SAPN, CCLHF-Net, DSSE-Net, MSU-Net) are NOT included:
they would need their original code bases.
"""
from __future__ import annotations

import timm
import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision.models import DenseNet121_Weights, VGG16_Weights, densenet121, vgg16

from ..data.datasets import IMAGENET_MEAN, IMAGENET_STD


# ------------------------------------------------------------------ detection baselines (return logits of shape (N,))
class _Squeeze(nn.Module):
    def __init__(self, net):
        super().__init__()
        self.net = net

    def forward(self, x):
        return self.net(x).squeeze(1)


def build_classifier(name: str, img_size: int = 512, pretrained: bool = True) -> nn.Module:
    if name == "vgg16":
        net = vgg16(weights=VGG16_Weights.IMAGENET1K_V1 if pretrained else None)
        net.classifier[-1] = nn.Linear(4096, 1)
    elif name == "densenet121":
        net = densenet121(weights=DenseNet121_Weights.IMAGENET1K_V1 if pretrained else None)
        net.classifier = nn.Linear(net.classifier.in_features, 1)
    elif name == "vit_b32":
        net = timm.create_model("vit_base_patch32_224", pretrained=pretrained, num_classes=1, img_size=img_size)
    else:
        raise ValueError(f"unknown classifier baseline {name}")
    return _Squeeze(net)


# ------------------------------------------------------------------ segmentation baselines (input in [0,1], logits (N,1,H,W))
class _Norm(nn.Module):
    def __init__(self):
        super().__init__()
        self.register_buffer("mean", torch.tensor(IMAGENET_MEAN).view(1, 3, 1, 1))
        self.register_buffer("std", torch.tensor(IMAGENET_STD).view(1, 3, 1, 1))

    def forward(self, x):
        return (x - self.mean) / self.std


def _dconv(i, o):
    return nn.Sequential(nn.Conv2d(i, o, 3, padding=1, bias=False), nn.BatchNorm2d(o), nn.ReLU(True),
                         nn.Conv2d(o, o, 3, padding=1, bias=False), nn.BatchNorm2d(o), nn.ReLU(True))


class UNet(nn.Module):
    """Classic U-Net, base width 32 (~7.8M parameters, matching Table 8)."""

    def __init__(self, base: int = 32):
        super().__init__()
        self.norm = _Norm()
        ch = [base, base * 2, base * 4, base * 8, base * 16]
        self.enc = nn.ModuleList([_dconv(3, ch[0])] + [_dconv(ch[i], ch[i + 1]) for i in range(4)])
        self.up = nn.ModuleList([nn.ConvTranspose2d(ch[i + 1], ch[i], 2, stride=2) for i in range(4)])
        self.dec = nn.ModuleList([_dconv(ch[i] * 2, ch[i]) for i in range(4)])
        self.out = nn.Conv2d(ch[0], 1, 1)

    def forward(self, x):
        x = self.norm(x)
        skips = []
        for i, e in enumerate(self.enc):
            x = e(x if i == 0 else F.max_pool2d(x, 2))
            skips.append(x)
        x = skips[-1]
        for i in reversed(range(4)):
            x = self.dec[i](torch.cat([self.up[i](x), skips[i]], 1))
        return self.out(x)


class FCN8s(nn.Module):
    def __init__(self, pretrained: bool = True):
        super().__init__()
        self.norm = _Norm()
        feats = vgg16(weights=VGG16_Weights.IMAGENET1K_V1 if pretrained else None).features
        self.f3, self.f4, self.f5 = feats[:17], feats[17:24], feats[24:31]  # pool3 /8, pool4 /16, pool5 /32
        self.fc = nn.Sequential(nn.Conv2d(512, 1024, 3, padding=1), nn.ReLU(True), nn.Dropout2d(0.5),
                                nn.Conv2d(1024, 1024, 1), nn.ReLU(True), nn.Dropout2d(0.5))
        self.s5, self.s4, self.s3 = nn.Conv2d(1024, 1, 1), nn.Conv2d(512, 1, 1), nn.Conv2d(256, 1, 1)

    def forward(self, x):
        size = x.shape[-2:]
        p3 = self.f3(self.norm(x)); p4 = self.f4(p3); p5 = self.f5(p4)
        y = self.s5(self.fc(p5))
        y = F.interpolate(y, size=p4.shape[-2:], mode="bilinear", align_corners=False) + self.s4(p4)
        y = F.interpolate(y, size=p3.shape[-2:], mode="bilinear", align_corners=False) + self.s3(p3)
        return F.interpolate(y, size=size, mode="bilinear", align_corners=False)


def _cbr(i, o):
    return [nn.Conv2d(i, o, 3, padding=1, bias=False), nn.BatchNorm2d(o), nn.ReLU(True)]


class SegNet(nn.Module):
    """VGG-16-style encoder/decoder; the decoder un-pools with the encoder's max-pool indices. Randomly initialised."""

    def __init__(self):
        super().__init__()
        self.norm = _Norm()
        ch, reps = [3, 64, 128, 256, 512, 512], [2, 2, 3, 3, 3]
        self.enc, self.dec = nn.ModuleList(), nn.ModuleList()
        for b in range(5):
            layers = []
            for k in range(reps[b]):
                layers += _cbr(ch[b] if k == 0 else ch[b + 1], ch[b + 1])
            self.enc.append(nn.Sequential(*layers))
        for b in reversed(range(5)):
            layers, last = [], (ch[b] if b > 0 else 64)
            for k in range(reps[b]):
                layers += _cbr(ch[b + 1], ch[b + 1] if k < reps[b] - 1 else last)
            self.dec.append(nn.Sequential(*layers))
        self.pool = nn.MaxPool2d(2, 2, return_indices=True)
        self.unpool = nn.MaxUnpool2d(2, 2)
        self.out = nn.Conv2d(64, 1, 1)

    def forward(self, x):
        x = self.norm(x)
        idxs, sizes = [], []
        for e in self.enc:
            x = e(x)
            sizes.append(x.shape)
            x, i = self.pool(x)
            idxs.append(i)
        for d, i, s in zip(self.dec, reversed(idxs), reversed(sizes)):
            x = d(self.unpool(x, i, output_size=s))
        return self.out(x)


def build_segmenter(name: str, pretrained: bool = True) -> nn.Module:
    if name == "unet":
        return UNet()
    if name == "fcn":
        return FCN8s(pretrained)
    if name == "segnet":
        return SegNet()
    raise ValueError(f"unknown segmentation baseline {name}")
