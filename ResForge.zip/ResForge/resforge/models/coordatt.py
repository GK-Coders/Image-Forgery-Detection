"""Coordinate Attention (Hou et al., CVPR 2021) as used in ResForge (paper Eqs. 5-6, Fig. 4).

Instead of one global average pool, the feature map is pooled separately along the width (Eq. 5, output indexed by
height h) and along the height (Eq. 6, output indexed by width w). The two direction-aware descriptors are encoded
jointly, split again and turned into two attention maps that re-weight the input along H and W.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class HSigmoid(nn.Module):
    def forward(self, x):
        return F.relu6(x + 3.0) / 6.0


class HSwish(nn.Module):
    def forward(self, x):
        return x * F.relu6(x + 3.0) / 6.0


class CoordAtt(nn.Module):
    def __init__(self, channels: int, reduction: int = 32):
        super().__init__()
        mip = max(8, channels // reduction)
        self.conv1 = nn.Conv2d(channels, mip, 1)
        self.bn1 = nn.BatchNorm2d(mip)
        self.act = HSwish()
        self.conv_h = nn.Conv2d(mip, channels, 1)
        self.conv_w = nn.Conv2d(mip, channels, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        _, _, h, w = x.shape
        z_h = x.mean(dim=3, keepdim=True)                       # Eq. (5): (N, C, H, 1)
        z_w = x.mean(dim=2, keepdim=True).permute(0, 1, 3, 2)   # Eq. (6): (N, C, W, 1)
        y = self.act(self.bn1(self.conv1(torch.cat([z_h, z_w], dim=2))))
        y_h, y_w = torch.split(y, [h, w], dim=2)
        a_h = torch.sigmoid(self.conv_h(y_h))                   # (N, C, H, 1)
        a_w = torch.sigmoid(self.conv_w(y_w.permute(0, 1, 3, 2)))  # (N, C, 1, W)
        return x * a_h * a_w
