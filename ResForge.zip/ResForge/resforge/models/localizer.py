"""Improved Mask R-CNN (paper Sec. 3.2): Res2Net-50 + CA + 3-level FPN backbone, standard RPN / RoIAlign, dilated-FCN mask head."""
from __future__ import annotations

from typing import Optional

import torch.nn as nn
from torchvision.models.detection import MaskRCNN
from torchvision.models.detection.faster_rcnn import FastRCNNPredictor, TwoMLPHead
from torchvision.models.detection.mask_rcnn import MaskRCNNHeads, MaskRCNNPredictor
from torchvision.models.detection.anchor_utils import AnchorGenerator
from torchvision.ops import MultiScaleRoIAlign

from ..data.datasets import IMAGENET_MEAN, IMAGENET_STD
from .backbone import ResNetFPNBackbone


def build_maskrcnn(cfg2, backbone: Optional[str] = None, coordinate_attention: Optional[bool] = None, pretrained: Optional[bool] = None) -> MaskRCNN:
    """Build the localisation model from the ``stage2`` config section.

    ``backbone`` / ``coordinate_attention`` / ``pretrained`` override the config (used by the ablation study, e.g.
    ``backbone='resnet18', coordinate_attention=False`` = the paper's "ResNet-18 + Mask R-CNN" baseline).
    """
    backbone = backbone or cfg2.backbone
    ca = cfg2.coordinate_attention if coordinate_attention is None else coordinate_attention
    pre = cfg2.pretrained if pretrained is None else pretrained
    body = ResNetFPNBackbone(backbone, coordinate_attention=ca, pretrained=pre, fpn_out_channels=cfg2.fpn_out_channels,
                             freeze_stem_and_layer1=cfg2.freeze_stem_and_layer1)
    n_levels = 3
    anchors = AnchorGenerator(sizes=(tuple(cfg2.anchor_sizes),) * n_levels, aspect_ratios=(tuple(cfg2.aspect_ratios),) * n_levels)
    names = ["0", "1", "2"]
    box_roi = MultiScaleRoIAlign(names, cfg2.box_roi_size, 2)
    mask_roi = MultiScaleRoIAlign(names, cfg2.mask_roi_size, 2)
    c = cfg2.fpn_out_channels
    model = MaskRCNN(
        body,
        num_classes=None,  # background + forged, heads given explicitly
        rpn_anchor_generator=anchors,
        rpn_nms_thresh=cfg2.rpn_nms_thresh,
        box_roi_pool=box_roi,
        box_head=TwoMLPHead(c * cfg2.box_roi_size ** 2, 1024),
        box_predictor=FastRCNNPredictor(1024, 2),
        mask_roi_pool=mask_roi,
        mask_head=MaskRCNNHeads(c, [256, 256, 256, 256], dilation=cfg2.mask_head_dilation),  # dilated FCN (Fig. 2)
        mask_predictor=MaskRCNNPredictor(256, 256, 2),
        min_size=cfg2.img_size,
        max_size=cfg2.img_size,
        image_mean=[float(v) for v in IMAGENET_MEAN],
        image_std=[float(v) for v in IMAGENET_STD],
        box_score_thresh=cfg2.box_score_thresh,
        box_detections_per_img=cfg2.max_detections,
    )
    return model


def weighted_loss(loss_dict, w) -> "torch.Tensor":  # noqa: F821
    """Eq. (3): L = l1*L_cls + l2*L_box + l3*L_mask (+ standard RPN terms)."""
    return (
        w.cls * loss_dict["loss_classifier"]
        + w.box * loss_dict["loss_box_reg"]
        + w.mask * loss_dict["loss_mask"]
        + w.rpn_objectness * loss_dict["loss_objectness"]
        + w.rpn_box * loss_dict["loss_rpn_box_reg"]
    )
