"""Stage 1: modified ResNet-18 for authentic/forged classification (paper Sec. 3.1, Fig. 1, Table 1).

* ImageNet-1K pretrained ResNet-18.
* ``conv1`` (+bn1) and the first two residual stages (``layer1``, ``layer2``) are frozen; ``layer3``, ``layer4`` and the
  new head are fine-tuned.
* Head: [Linear 512->512, ReLU, Dropout(0.5)] -> [512->256, ReLU, Dropout] -> [256->128, ReLU, Dropout] -> Linear(128->1).
  The single logit goes through a sigmoid (inside ``BCEWithLogitsLoss`` during training) to give p_forged.
"""
from __future__ import annotations

from typing import Iterable

import torch
import torch.nn as nn
from torchvision.models import ResNet18_Weights, resnet18


class ResForgeDetector(nn.Module):
    def __init__(self, pretrained: bool = True, freeze: Iterable[str] = ("conv1", "bn1", "layer1", "layer2"), dropout: float = 0.5):
        super().__init__()
        net = resnet18(weights=ResNet18_Weights.IMAGENET1K_V1 if pretrained else None)
        self.freeze_names = tuple(freeze)
        self.conv1, self.bn1, self.relu, self.maxpool = net.conv1, net.bn1, net.relu, net.maxpool
        self.layer1, self.layer2, self.layer3, self.layer4 = net.layer1, net.layer2, net.layer3, net.layer4
        self.avgpool = net.avgpool

        def block(i, o):
            return [nn.Linear(i, o), nn.ReLU(inplace=True), nn.Dropout(dropout)]

        self.head = nn.Sequential(*block(512, 512), *block(512, 256), *block(256, 128), nn.Linear(128, 1))
        for n in self.freeze_names:
            for p in getattr(self, n).parameters():
                p.requires_grad_(False)

    def train(self, mode: bool = True):
        super().train(mode)
        if mode:  # frozen layers keep their ImageNet BN statistics
            for n in self.freeze_names:
                getattr(self, n).eval()
        return self

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.maxpool(self.relu(self.bn1(self.conv1(x))))
        x = self.layer4(self.layer3(self.layer2(self.layer1(x))))
        x = torch.flatten(self.avgpool(x), 1)
        return self.head(x).squeeze(1)  # logits, shape (N,)
