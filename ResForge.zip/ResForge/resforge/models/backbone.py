"""Res2Net(-50) + Coordinate Attention + 3-level FPN backbone for Mask R-CNN (paper Sec. 3.2.1, Figs. 2-3).

Res2Net splits the features of the first 1x1 conv into s=4 subsets and connects the 3x3 convs hierarchically
(Eq. 4); the subsets are then concatenated. ResForge applies Coordinate Attention *immediately after that
concatenation*, i.e. right before the block's final 1x1 convolution. In timm's ``Bottle2neck`` this is exactly the input of
``conv3``, so we wrap ``conv3`` as ``Sequential(CoordAtt, conv3)``; the pretrained weights are loaded first, so ImageNet
initialisation is preserved (CA layers are freshly initialised).

The same insertion is available for plain ResNets (used for the ablation baseline "ResNet-18 + Mask R-CNN"): CA is
placed after ``bn2`` of every BasicBlock (before the residual add) or before ``conv3`` of every Bottleneck.
"""
from __future__ import annotations

from collections import OrderedDict
from typing import List

import timm
import torch
import torch.nn as nn
from torchvision.ops import FeaturePyramidNetwork

from .coordatt import CoordAtt


def add_coordinate_attention(layers: List[nn.Sequential]) -> int:
    """Insert CA into every residual block of the given stages. Returns the number of blocks patched."""
    n = 0
    for stage in layers:
        for blk in stage:
            if isinstance(getattr(blk, "conv3", None), nn.Conv2d):  # Bottleneck / Bottle2neck
                blk.conv3 = nn.Sequential(CoordAtt(blk.conv3.in_channels), blk.conv3)
                n += 1
            elif isinstance(getattr(blk, "conv2", None), nn.Conv2d) and hasattr(blk, "bn2"):  # BasicBlock
                blk.bn2 = nn.Sequential(blk.bn2, CoordAtt(blk.conv2.out_channels))
                n += 1
    return n


class ResNetFPNBackbone(nn.Module):
    """timm ResNet-family body (C3, C4, C5) + torchvision FPN. Output keys '0','1','2' (strides 8, 16, 32)."""

    def __init__(
        self,
        name: str = "res2net50_26w_4s",
        coordinate_attention: bool = True,
        pretrained: bool = True,
        fpn_out_channels: int = 256,
        freeze_stem_and_layer1: bool = True,
    ):
        super().__init__()
        m = timm.create_model(name, pretrained=pretrained)  # weights loaded BEFORE CA is inserted
        self.stem = nn.Sequential(m.conv1, m.bn1, m.act1, m.maxpool)
        self.layer1, self.layer2, self.layer3, self.layer4 = m.layer1, m.layer2, m.layer3, m.layer4
        self.num_ca_blocks = 0
        if coordinate_attention:
            # stages feeding the FPN only; layer1 stays frozen & purely pretrained
            self.num_ca_blocks = add_coordinate_attention([self.layer2, self.layer3, self.layer4])
        in_ch = [m.feature_info[i]["num_chs"] for i in (2, 3, 4)]
        self.fpn = FeaturePyramidNetwork(in_ch, fpn_out_channels)
        self.out_channels = fpn_out_channels
        self.freeze = freeze_stem_and_layer1
        if self.freeze:
            for mod in (self.stem, self.layer1):
                for p in mod.parameters():
                    p.requires_grad_(False)

    def train(self, mode: bool = True):
        super().train(mode)
        if mode and self.freeze:  # keep frozen BN statistics fixed
            self.stem.eval()
            self.layer1.eval()
        return self

    def forward(self, x: torch.Tensor):
        c2 = self.layer1(self.stem(x))
        c3 = self.layer2(c2)
        c4 = self.layer3(c3)
        c5 = self.layer4(c4)
        return self.fpn(OrderedDict([("0", c3), ("1", c4), ("2", c5)]))
