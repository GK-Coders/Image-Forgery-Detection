# ResForge — Image Forgery Detection and Region Localization with Residual Feature Representation Learning

Reference implementation (PyTorch) of the two-stage **ResForge** pipeline from
*"Image Forgery Detection and Region Localization Using Residual Feature Representation Learning"* (IJIES).

```
            ┌──────────────────────────────┐   forged   ┌──────────────────────────────────────────────┐
 image ───▶ │ Stage 1  ResNet-18 (modified)│ ─────────▶ │ Stage 2  improved Mask R-CNN                 │ ──▶ forged-region mask
            │ conv1/layer1/layer2 frozen   │            │ Res2Net-50 + Coordinate Attention + 3-level  │
            │ layer3/4 + MLP head tuned    │            │ FPN · RPN · RoIAlign · dilated-FCN mask head │
            └──────────────────────────────┘            └──────────────────────────────────────────────┘
                     │ authentic                                      loss = 1·L_cls + 1·L_box + 2·L_mask
                     ▼
                empty mask
```

* **Stage 1 – detection.** ImageNet ResNet-18, `conv1` + `layer1` + `layer2` frozen, `layer3`/`layer4` and a
  `512→512→256→128→1` head (ReLU + Dropout 0.5) fine-tuned; BCE + Adam; threshold τ fitted on the validation split.
* **Stage 2 – localization.** Mask R-CNN whose backbone is Res2Net-50 with **Coordinate Attention** inserted right after the
  multi-scale feature concatenation of each block, feeding a 3-level FPN; weighted multi-task loss (Eq. 3), AdamW.
* **Protocol.** Strict group-aware 60/10/30 splits (`GroupShuffleSplit`, parent-image groups) repeated over 20 seeds, mean ± SD,
  paired t-tests with Holm–Bonferroni correction, robustness to blur / noise / JPEG, runtime profile.

> **Status / honesty note.** All code runs end-to-end (unit tests + a CPU smoke test on synthetic data pass). The paper's numbers
> (e.g. F1 92.5 ± 0.4 / IoU 88.7 ± 0.5 on CASIA v2) have **not** been re-obtained by this code: the real datasets and a GPU were not
> available when it was written, and several details are not specified in the paper (see [Assumptions](#assumptions-and-known-differences)).
> Treat the paper's results as targets, not as guarantees.

---

## Repository layout

```
ResForge/
├── configs/
│   ├── default.yaml            # every hyper-parameter of the paper (Table 1 + Sec. 3-4), tagged [paper] / [assumed]
│   └── demo.yaml               # tiny CPU settings for the synthetic smoke test
├── notebooks/
│   ├── 00_end_to_end_demo_synthetic.ipynb     # whole pipeline on synthetic data, CPU, ~5-10 min (outputs included)
│   ├── 01_dataset_preparation.ipynb           # CASIA v2 / DEFACTO-12k / NIST16 → metadata.csv + masks, Table-2 check
│   ├── 02_stage1_detection.ipynb              # frozen ResNet-18 detector (+ optional baselines), ROC
│   ├── 03_stage2_localization.ipynb           # Res2Net+CA Mask R-CNN, qualitative results, ablation (Table 7)
│   └── 04_evaluation_robustness_stats.ipynb   # 20-seed protocol, full pipeline, robustness, runtime, statistics
├── resforge/
│   ├── data/        metadata.py · splits.py · datasets.py · prepare.py · synthetic.py
│   ├── models/      coordatt.py · backbone.py (Res2Net+CA+FPN) · localizer.py (Mask R-CNN) · detector.py · baselines.py
│   ├── train/       classifier.py (Stage 1 / baselines) · localizer.py (Stage 2 / segmentation baselines)
│   ├── eval/        metrics.py · pipeline.py · robustness.py · stats.py · profiling.py
│   ├── experiment.py            # multi-seed runner + aggregation (resumable)
│   ├── nbutils.py · viz.py      # notebook helpers
│   └── config.py · utils.py
├── scripts/         prepare_data.py · run_experiment.py
├── tests/           unit tests, dataset-preparation tests, end-to-end smoke test
├── requirements.txt · pyproject.toml · LICENSE · .github/workflows/ci.yml
└── data/  outputs/  (git-ignored)
```

## Quick start

```bash
git clone <your-repo-url> ResForge && cd ResForge
python -m venv .venv && source .venv/bin/activate        # optional
pip install -r requirements.txt                          # for GPU pick the matching torch build first: https://pytorch.org
pip install -e .

pytest -q -m "not slow"                                  # ~20 s: unit tests (no training)
RESFORGE_DEMO=1 jupyter lab notebooks/                   # run 00_end_to_end_demo_synthetic.ipynb (synthetic data, CPU)
```

Tested with Python 3.13, PyTorch 2.15, torchvision 0.29, timm 1.0.31 on CPU. The paper used Python 3.8, PyTorch 2.1.0, CUDA 12.1, RTX 3050 (8 GB).

## Datasets

The datasets are **not** redistributed. Download them and convert them to the unified format with notebook 01 or `scripts/prepare_data.py`.

| Dataset | Source | Used as (paper Table 2) |
|---|---|---|
| **CASIA v2** | CASIA ITDE v2.0 (`Au/` 7,491 authentic, `Tp/` 5,123 tampered). Ground-truth masks: <https://github.com/namtpham/casia2groundtruth> | 12,614 images → 7,568 / 1,262 / 3,784 |
| **DEFACTO-12k** | <https://defactodataset.github.io/> (+ the matching MS-COCO images for the authentic parents) | class-balanced 6,000 + 6,000 → 7,200 / 1,200 / 3,600 |
| **NIST16** | NIST Nimble Challenge 2016 (registration required, <https://www.nist.gov/>) | 564 + 564 → 676 / 114 / 338 |

```bash
python scripts/prepare_data.py casia2     --casia-root /data/CASIA2 --out data/processed            # masks by pixel subtraction (paper)
python scripts/prepare_data.py casia2     --casia-root /data/CASIA2 --out data/processed --mask-source provided --gt-dir /data/casia2groundtruth
python scripts/prepare_data.py defacto12k --defacto-root /data/DEFACTO --coco-dir /data/coco --out data/processed
python scripts/prepare_data.py nist16     --out data/processed --tampered-dir ... --mask-dir ... --authentic-dir ... --pairs-csv ...
```

Everything downstream only needs `data/processed/<dataset>_metadata.csv`:

| column | meaning |
|---|---|
| `image_path` | relative to `data_root` (absolute paths also work) |
| `mask_path` | binary mask (0/255) for forged images, empty otherwise |
| `label` | 0 authentic · 1 forged |
| `group` | parent-image id — all derivatives of one authentic source share it (leak-free splitting) |
| `dataset`, `forgery_type` | bookkeeping |

If your copy of a dataset is organised differently from what `prepare.py` expects, write this CSV yourself — nothing else is needed.

## Running the experiments

1. **Notebooks** (`notebooks/01 → 04`) — step-by-step with plots; set `DATASET = "casia2" | "defacto12k" | "nist16"` at the top.
2. **CLI** — the same protocol without Jupyter, resumable per seed:

```bash
python scripts/run_experiment.py --dataset casia2 --metadata data/processed/casia2_metadata.csv --data-root data/processed \
       --n-runs 20 --baselines                      # outputs/casia2/seed*/metrics.json + aggregated mean ± SD
python scripts/run_experiment.py --dataset synthetic --metadata data/processed/synthetic_metadata.csv --config configs/demo.yaml --n-runs 2
```

**Compute budget.** One seed = one Stage-1 + one Stage-2 training (≈ 50 epochs each, early-stopped); the paper reports ~215 min *per epoch* for ResForge on
an RTX 3050. Twenty seeds × three datasets × baselines is a multi-day GPU job — begin with `--n-runs 2`.
If Mask R-CNN at 512×512 / batch 16 runs out of GPU memory, lower `stage2.micro_batch_size` (e.g. 2–4): gradient accumulation keeps the effective batch at 16.
On Windows set `data.num_workers: 0`.

## Paper → code map

| Paper | Where |
|---|---|
| Sec. 3.1, Fig. 1 – frozen ResNet-18 + MLP head, Eqs. 1-2 | `resforge/models/detector.py`, `train/classifier.py`, `eval/metrics.select_threshold` |
| Sec. 3.1 – group-aware 60/10/30 split, 20 seeds, balanced sampling | `data/splits.py`, `train/classifier._loader`, `experiment.py` |
| Sec. 3.2 – improved Mask R-CNN, anchors/NMS/RoIAlign, Eq. 3 | `models/localizer.py`, `train/localizer.py` |
| Sec. 3.2.1, Fig. 3, Eq. 4 – Res2Net (s = 4) + FPN | `models/backbone.py` (timm `res2net50_26w_4s`) |
| Figs. 3-4, Eqs. 5-6 – Coordinate Attention after the multi-scale concat | `models/coordatt.py`, `backbone.add_coordinate_attention` |
| Table 1 – training settings | `configs/default.yaml` |
| Sec. 4.1 – datasets, CASIA subtraction masks (nearest resize, threshold 127, 3×3 median) | `data/prepare.py` |
| Sec. 4.3, Eqs. 7-15 – metrics (macro-averaged per image) | `eval/metrics.py` |
| Tables 3-4 – comparison with VGG-16 / DenseNet-121 / ViT and U-Net / FCN / SegNet | `models/baselines.py`, `experiment.py` |
| Sec. 4.5, Figs. 7-9 – blur k∈{3,15}, noise var∈{0.002,0.01}, JPEG q∈{50,90} | `eval/robustness.py`, notebook 04 §C |
| Sec. 4.6, Tables 5-6 – paired t-test, Holm–Bonferroni, d_z, CI | `eval/stats.py`, notebook 04 §E |
| Table 7 – ablation (ResNet-18 / +Res2Net / +CA / full) | notebook 03 (`build_maskrcnn(..., backbone=, coordinate_attention=)`) |
| Table 8 – parameters, latency, peak memory | `eval/profiling.py`, notebook 04 §D |
| Stage-1 errors → empty mask; standalone vs. full pipeline | `eval/pipeline.py` |

## Assumptions and known differences

Everything in `configs/default.yaml` is tagged `[paper]` or `[assumed]`. Details the paper does not specify, and how this repo resolves them:

**Modelling**
1. *Output activation.* Algorithm 1 says "Softmax" but the text (Sec. 3.1, Fig. 1) describes one logit + sigmoid; the repo uses one logit, sigmoid, BCE.
2. *Early-stopping criterion.* Stage 1: validation loss. Stage 2: validation mean IoU at threshold 0.5. Best weights are restored.
3. *Frozen layers* keep their BatchNorm statistics fixed (eval mode); the rest train normally.
4. *Anchors.* Five scales (16…256) × three ratios are placed on **each** of the three FPN levels (15 anchors/location) — the paper lists five scales but a 3-level FPN.
5. *FPN / backbone.* FPN on C3–C5 (strides 8/16/32), 256 channels; stem + `layer1` frozen (torchvision `trainable_layers=3`); CA inserted in stages 2–4 only. ImageNet weights are loaded *before* CA is inserted.
6. *Mask head.* Fig. 2 says "dilated FCN": four 3×3 convs with dilation 2, then the standard deconv predictor.
7. *Instances.* Ground-truth masks become Mask R-CNN targets via 8-connected components (area ≥ 16 px, at most 20 per image).
8. *Loss.* Eq. 3 weights (1, 1, 2) as in the paper; the two standard RPN losses are added with weight 1.
9. *Heat-map & binarisation.* Heat-map = per-pixel maximum over instances of `score × mask probability`; the binary threshold is tuned on validation pixel-F1 (grid 0.1–0.9). Set `stage2.tune_loc_threshold: false` for a fixed 0.5.
10. *Augmentation.* None (the paper mentions none); a horizontal-flip switch exists (`augment`).
11. *Resizing.* Bilinear to 256² (Stage 1) / 512² (Stage 2); robustness perturbations are applied after resizing.

**Data**
12. *CASIA v2 masks.* The paper subtracts each tampered image from its authentic background, then resizes (nearest), thresholds at 127, applies a 3×3 median. Whether the difference is normalised before the threshold is not stated; this repo rescales it to 0–255 (`normalize_diff=True`). Pairs of different size and empty / > 90 %-coverage masks are discarded. Such forged images stay in Stage 1 but have no mask for Stage 2, so the number of Stage-2 images is below 5,123. The community `*_gt.png` masks are available via `--mask-source provided`.
13. *DEFACTO-12k.* The paper does not say how the subset was drawn; the repo takes an equal share of splicing / copy-move / inpainting (= "removal"), one tampered image per MS-COCO parent, plus those parents as authentic images.
14. *NIST16.* Requires NIST registration; the preparation routine could not be tested against the real release (only against fake folders with the documented structure). Check `*_metadata.csv` and the Table-2 counts in notebook 01.
15. *Split sizes.* `GroupShuffleSplit` partitions groups, so image counts match Table 2 only approximately.

**Comparison models**
16. "ViT-132" is interpreted as **ViT-B/32** (`timm vit_base_patch32_224`, 512² input). U-Net (base 32), FCN-8s (VGG-16) and SegNet (VGG-16 style, random init) are compact re-implementations; their optimisers/learning rates are assumed (Adam 1e-4).
17. The literature methods of Tables 5, 6, 9, 10 (SSR-IFL, FreNet, AFCMS-Net, SAPN, CCLHF-Net, DSSE-Net, MSU-Net) are **not** implemented; `eval/stats.py` accepts per-run scores of any method if you add them.

**Complexity.** The model built here has **≈ 55.4 M parameters** (Stage 1: 11.6 M; Stage 2: 43.8 M = Res2Net-50 body 24.0 M + CA, FPN 2.7 M, RPN 0.6 M, RoI heads 16.5 M),
whereas Table 8 of the paper lists 37.5 M. A Res2Net-50 + FPN + Mask R-CNN stack cannot be that small, so absolute parameter counts and latencies printed by `eval/profiling.py` will differ from Table 8.

## Paper results (targets)

| | CASIA v2 | DEFACTO-12k | NIST16 |
|---|---|---|---|
| Detection F1 (%) | 92.5 ± 0.4 | 90.3 ± 0.3 | 90.5 ± 0.3 |
| Detection AUC (%) | 95.6 ± 0.3 | 94.8 ± 0.3 | 96.4 ± 0.7 |
| Pixel F1 (%) | 94.0 ± 0.4 | 92.6 ± 0.3 | 88.6 ± 0.3 |
| Pixel AUC (%) | 93.1 ± 0.3 | 90.6 ± 0.3 | 89.3 ± 0.7 |
| IoU (%) | 88.7 ± 0.5 | 86.2 ± 0.3 | 79.6 ± 0.5 |

## Tests

```bash
pytest -q -m "not slow"   # shapes, freezing, CA placement, Mask R-CNN losses, splits, metrics, Holm correction, dataset preparation
pytest -q                 # + end-to-end smoke test (tiny synthetic data, trains both stages on CPU, ~2 min)
```

## Publishing this repository on GitHub

```bash
cd ResForge
git init -b main
git add .
git commit -m "Initial commit: ResForge reference implementation"
git remote add origin https://github.com/<your-user>/<your-repo>.git
git push -u origin main
```

`data/`, `outputs/` and checkpoints (`*.pt`) are git-ignored; the GitHub Actions workflow in `.github/workflows/ci.yml` runs the tests on CPU.
Before publishing, complete the `volume / pages` fields in the citation below and double-check that the licence (MIT) is the one you want.

## Citation

```bibtex
@article{shivakumar2026resforge,
  title   = {Image Forgery Detection and Region Localization Using Residual Feature Representation Learning},
  author  = {Kodavayu Sankar Shivakumar and Vishnu Kanth Karwa and Premachand Doddamagadi Ramanaika and
             Devappa Girish Kumar and Pani Rama Prasad and Sangamesh Channabasappa Jalade},
  journal = {International Journal of Intelligent Engineering and Systems},
  year    = {2026},
  note    = {volume, issue and pages to be completed}
}
```

Released under the MIT License (see `LICENSE`). Dataset licences are those of their respective owners.
