#!/usr/bin/env python
"""Run the paper's multi-seed protocol for one dataset (resumable).

python scripts/run_experiment.py --dataset casia2 --metadata data/processed/casia2_metadata.csv --data-root data/processed
python scripts/run_experiment.py --dataset casia2 ... --n-runs 20 --baselines          # full protocol incl. comparison models
python scripts/run_experiment.py --dataset synthetic ... --config configs/demo.yaml     # CPU smoke test
"""
import argparse

from resforge import load_config
from resforge.data.metadata import check_files, load_metadata
from resforge.experiment import run_experiment


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dataset", required=True)
    ap.add_argument("--metadata", required=True)
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--config", default=None, help="YAML overlay on configs/default.yaml")
    ap.add_argument("--n-runs", type=int, default=None, help="number of seeds (paper: 20)")
    ap.add_argument("--baselines", action="store_true", help="also train the comparison models")
    ap.add_argument("--out", default=None)
    ap.add_argument("--num-workers", type=int, default=None)
    a = ap.parse_args()

    cfg = load_config(a.config)
    root = a.data_root or cfg.paths.data_root
    df = load_metadata(a.metadata)
    check_files(df, root)
    seeds = range(a.n_runs if a.n_runs is not None else cfg.data.split.n_runs)
    agg = run_experiment(a.dataset, df, root, cfg, seeds=seeds, out_dir=a.out, run_baselines=a.baselines or None, num_workers=a.num_workers)
    print(agg.to_string(index=False))


if __name__ == "__main__":
    main()
