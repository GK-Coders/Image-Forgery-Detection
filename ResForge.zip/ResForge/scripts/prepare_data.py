#!/usr/bin/env python
"""Build unified metadata + masks from raw datasets.

Examples
--------
python scripts/prepare_data.py casia2 --casia-root /data/CASIA2 --out data/processed
python scripts/prepare_data.py casia2 --casia-root /data/CASIA2 --out data/processed --mask-source provided --gt-dir /data/casia2groundtruth
python scripts/prepare_data.py defacto12k --defacto-root /data/DEFACTO --coco-dir /data/coco --out data/processed
python scripts/prepare_data.py nist16 --out data/processed --tampered-dir /data/nist/probe --mask-dir /data/nist/masks \
        --authentic-dir /data/nist/base --pairs-csv /data/nist/pairs.csv
python scripts/prepare_data.py synthetic --out data/processed        # tiny fake data for smoke tests
"""
import argparse
from pathlib import Path

from resforge.data.prepare import prepare_casia2, prepare_defacto12k, prepare_nist16
from resforge.data.synthetic import make_synthetic_dataset


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    c = sub.add_parser("casia2")
    c.add_argument("--casia-root", required=True, help="folder containing Au/ and Tp/")
    c.add_argument("--out", required=True, help="output data root (metadata CSV + masks are written here)")
    c.add_argument("--mask-source", choices=["subtraction", "provided"], default="subtraction")
    c.add_argument("--gt-dir", help="folder with *_gt.png (namtpham/casia2groundtruth) when --mask-source provided")
    c.add_argument("--mask-size", type=int, default=512)

    d = sub.add_parser("defacto12k")
    d.add_argument("--defacto-root", required=True)
    d.add_argument("--coco-dir", required=True)
    d.add_argument("--out", required=True)
    d.add_argument("--n-tampered", type=int, default=6000)
    d.add_argument("--mask-size", type=int, default=512)
    d.add_argument("--seed", type=int, default=0)

    n = sub.add_parser("nist16")
    n.add_argument("--out", required=True)
    n.add_argument("--nc-root"); n.add_argument("--index-csv")
    n.add_argument("--tampered-dir"); n.add_argument("--mask-dir"); n.add_argument("--authentic-dir"); n.add_argument("--pairs-csv")
    n.add_argument("--mask-size", type=int, default=512)

    s = sub.add_parser("synthetic")
    s.add_argument("--out", required=True)
    s.add_argument("--n-parents", type=int, default=48)
    s.add_argument("--size", type=int, default=160)

    a = ap.parse_args()
    out = Path(a.out)
    if a.cmd == "casia2":
        prepare_casia2(a.casia_root, out, a.mask_source, a.gt_dir, a.mask_size)
    elif a.cmd == "defacto12k":
        prepare_defacto12k(a.defacto_root, a.coco_dir, out, a.n_tampered, a.mask_size, a.seed)
    elif a.cmd == "nist16":
        prepare_nist16(out, a.nc_root, a.index_csv, a.tampered_dir, a.mask_dir, a.authentic_dir, a.pairs_csv, a.mask_size)
    else:
        make_synthetic_dataset(out, "synthetic", a.n_parents, a.size)
        print(f"wrote {out}/synthetic_metadata.csv")


if __name__ == "__main__":
    main()
